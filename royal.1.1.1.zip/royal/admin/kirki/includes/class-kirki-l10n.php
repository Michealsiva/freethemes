<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'royal';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'royal' ),
				'background-image'      => esc_attr__( 'Background Image', 'royal' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'royal' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'royal' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'royal' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'royal' ),
				'inherit'               => esc_attr__( 'Inherit', 'royal' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'royal' ),
				'cover'                 => esc_attr__( 'Cover', 'royal' ),
				'contain'               => esc_attr__( 'Contain', 'royal' ),
				'background-size'       => esc_attr__( 'Background Size', 'royal' ),
				'fixed'                 => esc_attr__( 'Fixed', 'royal' ),
				'scroll'                => esc_attr__( 'Scroll', 'royal' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'royal' ),
				'left-top'              => esc_attr__( 'Left Top', 'royal' ),
				'left-center'           => esc_attr__( 'Left Center', 'royal' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'royal' ),
				'right-top'             => esc_attr__( 'Right Top', 'royal' ),
				'right-center'          => esc_attr__( 'Right Center', 'royal' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'royal' ),
				'center-top'            => esc_attr__( 'Center Top', 'royal' ),
				'center-center'         => esc_attr__( 'Center Center', 'royal' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'royal' ),
				'background-position'   => esc_attr__( 'Background Position', 'royal' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'royal' ),
				'on'                    => esc_attr__( 'ON', 'royal' ),
				'off'                   => esc_attr__( 'OFF', 'royal' ),
				'all'                   => esc_attr__( 'All', 'royal' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'royal' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'royal' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'royal' ),
				'greek'                 => esc_attr__( 'Greek', 'royal' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'royal' ),
				'khmer'                 => esc_attr__( 'Khmer', 'royal' ),
				'latin'                 => esc_attr__( 'Latin', 'royal' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'royal' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'royal' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'royal' ),
				'arabic'                => esc_attr__( 'Arabic', 'royal' ),
				'bengali'               => esc_attr__( 'Bengali', 'royal' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'royal' ),
				'tamil'                 => esc_attr__( 'Tamil', 'royal' ),
				'telugu'                => esc_attr__( 'Telugu', 'royal' ),
				'thai'                  => esc_attr__( 'Thai', 'royal' ),
				'serif'                 => _x( 'Serif', 'font style', 'royal' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'royal' ),
				'monospace'             => _x( 'Monospace', 'font style', 'royal' ),
				'font-family'           => esc_attr__( 'Font Family', 'royal' ),
				'font-size'             => esc_attr__( 'Font Size', 'royal' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'royal' ),
				'line-height'           => esc_attr__( 'Line Height', 'royal' ),
				'font-style'            => esc_attr__( 'Font Style', 'royal' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'royal' ),
				'top'                   => esc_attr__( 'Top', 'royal' ),
				'bottom'                => esc_attr__( 'Bottom', 'royal' ),
				'left'                  => esc_attr__( 'Left', 'royal' ),
				'right'                 => esc_attr__( 'Right', 'royal' ),
				'center'                => esc_attr__( 'Center', 'royal' ),
				'justify'               => esc_attr__( 'Justify', 'royal' ),
				'color'                 => esc_attr__( 'Color', 'royal' ),
				'add-image'             => esc_attr__( 'Add Image', 'royal' ),
				'change-image'          => esc_attr__( 'Change Image', 'royal' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'royal' ),
				'add-file'              => esc_attr__( 'Add File', 'royal' ),
				'change-file'           => esc_attr__( 'Change File', 'royal' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'royal' ),
				'remove'                => esc_attr__( 'Remove', 'royal' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'royal' ),
				'variant'               => esc_attr__( 'Variant', 'royal' ),
				'subsets'               => esc_attr__( 'Subset', 'royal' ),
				'size'                  => esc_attr__( 'Size', 'royal' ),
				'height'                => esc_attr__( 'Height', 'royal' ),
				'spacing'               => esc_attr__( 'Spacing', 'royal' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'royal' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'royal' ),
				'light'                 => esc_attr__( 'Light 200', 'royal' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'royal' ),
				'book'                  => esc_attr__( 'Book 300', 'royal' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'royal' ),
				'regular'               => esc_attr__( 'Normal 400', 'royal' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'royal' ),
				'medium'                => esc_attr__( 'Medium 500', 'royal' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'royal' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'royal' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'royal' ),
				'bold'                  => esc_attr__( 'Bold 700', 'royal' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'royal' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'royal' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'royal' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'royal' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'royal' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'royal' ),
				'add-new'           	=> esc_attr__( 'Add new', 'royal' ),
				'row'           		=> esc_attr__( 'row', 'royal' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'royal' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'royal' ),
				'back'                  => esc_attr__( 'Back', 'royal' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'royal' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'royal' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'royal' ),
				'none'                  => esc_attr__( 'None', 'royal' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'royal' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'royal' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'royal' ),
				'initial'               => esc_attr__( 'Initial', 'royal' ),
				'select-page'           => esc_attr__( 'Select a Page', 'royal' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'royal' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'royal' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'royal' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'royal' ),
			);

			$config = apply_filters( 'kirki/config', array() );

			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
