<?php

function royal_custom_styles($custom) {
$custom = '';	
		$sticky_header_position = get_theme_mod('sticky_header_position');

     if( $sticky_header_position == 'bottom') {
          $custom .= ".sticky-header #nav-wrap {  top: auto!important;
               bottom:0; }"."\n";  
          $custom .= ".sticky-header #nav-wrap .nav-menu .sub-menu {  top: auto;
               bottom:100%; }"."\n";    
     }     

     $page_title_bar = get_theme_mod('page_titlebar',1);
     if($page_title_bar == 2) {   	
		$custom .= ".breadcrumb-wrap {
			display: none;
		}"."\n";	
     } 

     $page_title_bar_status = get_theme_mod('page_titlebar_text');
     if( $page_title_bar_status == 2 ) {
     	    $custom .= ".breadcrumb-wrap .entry-header .entry-title {
     			display: none;
     		}"."\n";
               $custom .= ".columns.breadcrumb #breadcrumb #crumbs {
                    bottom:20px;
               }"."\n";
     }     

	//Output all the styles
	wp_add_inline_style( 'royal-style', $custom );    	
}


add_action( 'wp_enqueue_scripts', 'royal_custom_styles' );  


