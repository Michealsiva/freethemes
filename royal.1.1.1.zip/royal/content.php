<?php
/**
 * @package Royal
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php 
		$featured_image = get_theme_mod( 'featured_image',true );
	    $featured_image_size = get_theme_mod ('featured_image_size','1');
		if( $featured_image ) : 
		        if ( $featured_image_size == '1' ) :?>		
						<div class="post-thumb">
						  <?php	if( $featured_image && has_post_thumbnail() ) : 
								    the_post_thumbnail('royal-blog-full-width');
			                     endif;?>
			            </div> <?php
		        else: ?>
		 	            <div class="post-thumb">
		 	                 <?php if( has_post_thumbnail() && ! post_password_required() ) :   
					               the_post_thumbnail('royal-small-featured-image-width');
								endif;?>
			             </div>  <?php				
	            endif; 
		endif; ?>   
		<?php do_action('royal_before_entry_header'); ?>

	<header class="entry-header">
		<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
		<?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
			<footer class="entry-title-meta">
				<?php if(function_exists('royal_entry_top_meta') ) {
						   royal_entry_top_meta(); 
						} ?> 
			</footer>
		<?php endif; ?>
	</header>
<?php do_action('royal_after_entry_header'); ?>

	<div class="entry-content">
		<?php
			/* translators: %s: Name of current post */
			the_content();
		?>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages: ', 'royal' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
<?php do_action('royal_before_entry_footer'); ?>
	<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
		<footer class="entry-footer">
			<?php if(function_exists('royal_entry_bottom_meta') ) {
			     royal_entry_bottom_meta();
			} ?>
		</footer><!-- .entry-footer -->
	<?php endif;?>
<?php do_action('royal_after_entry_footer'); ?>
	
</article><!-- #post-## -->