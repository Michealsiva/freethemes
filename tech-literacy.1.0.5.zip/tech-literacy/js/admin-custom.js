(function( $ ) {
	$(function() {
		if( $.fn.iconpicker ) {
			$('.faip').iconpicker(); 
	    }
	});

})( jQuery );
