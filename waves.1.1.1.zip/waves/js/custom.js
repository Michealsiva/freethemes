(function($){
	$(function(){
		$('.flexslider').flexslider();
	});  
})(jQuery);