<?php
/**
 * The template used for displaying page breadcrumb
 *
 * @package waves
 */
?>
<div class="breadcrumb-wrap">
	<div class="breadcrumb">
		<div class="container">
			<div class="breadcrumb-left eight columns">
				<?php the_title('<h4>','</h4>');?>			
			</div>
			<div class="breadcrumb-right eight columns">
				<?php if( function_exists('waves_breadcrumbs') ) {
					waves_breadcrumbs(); 
				  }?>
			</div>
		</div>
	</div>	
</div>