<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package waves
 */
 get_header('blank'); 

 $breadcrumb = get_theme_mod( 'breadcrumb' ); ?>    
<?php if( $breadcrumb ) : ?>
	<?php $header_bread = 'header-bread'; 
	else:   $header_bread = '';
	endif; ?>  

	<?php do_action('waves_before_header'); ?>
	
	<header id="masthead" class="site-header header-image <?php echo waves_site_style_header_class(); ?>" role="banner">

	<div class="header-wrapper <?php echo $header_bread; ?>">
	<?php if ( get_theme_mod ('header_overlay',false ) ) { 
		   echo '<div class="overlay overlay-header"></div>';     
	} ?>
	<?php if( is_active_sidebar( 'top-left' )  || is_active_sidebar( 'top-left' ) ): ?>
	<div class="top-nav">
			<div class="container">		
			<?php if( is_active_sidebar( 'top-left' ) ) : ?>
				<div class="ten columns">
					<div class="cart">
						<?php dynamic_sidebar('top-left' ); ?>
					</div>
				</div>
			<?php endif; ?>
			<?php if( is_active_sidebar('top-right' ) ) : ?>
				<div class="columns six">
					<div class="social">
						<?php dynamic_sidebar('top-right' ); ?>  
					</div>
				</div>
			<?php endif; ?>
			</div>
		</div> <!-- .top-nav -->
	<?php endif;?>
		
	<div class="branding"> 
		<div class="container">
			<div class="six columns">    
				<nav id="site-navigation" class="main-navigation navigation-left clearfix" role="navigation">
					<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><?php echo apply_filters('waves_responsive_left_menu_title',__('Primary Left Menu','waves') ); ?></button>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-left') ); ?>   
				</nav><!-- #site-navigation -->
			</div>
			<div class="four columns">
				<div class="site-branding">
					<?php 
						$logo_title = get_theme_mod( 'logo_title' );
						$logo = get_theme_mod( 'logo', '' );
						$tagline = get_theme_mod( 'tagline',true);
						if( $logo_title && function_exists( 'the_custom_logo' ) ) {
                                the_custom_logo();     
					        }elseif( $logo != '' && $logo_title ) { ?>
							   <h1 class="site-title img-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($logo) ?>"></a></h1>
					<?php	}else { ?>
								<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
						    <?php } ?>
					<?php if( $tagline ) : ?>
							<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
					<?php endif; ?>
				</div><!-- .site-branding -->
				
			</div>
			<div class="six columns">    
				<nav id="site-navigation-right" class="main-navigation navigation-right clearfix" role="navigation">
					<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><?php echo apply_filters('waves_responsive_right_menu_title',__('Primary Right Menu','waves') ); ?></button>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-right','menu_class' => 'menu nav-menu' ) ); ?>   
				</nav><!-- #site-navigation -->
			</div> 
		</div>
		<?php do_action('waves_after_primary_nav'); ?>
	</div><!-- .branding -->
</div>   
		
<?php $breadcrumb = get_theme_mod('breadcrumb',true ); ?> 
<?php if( $breadcrumb ) : ?>
<div class="breadcrumb">
<div class="container">
	<div class="breadcrumb-left eight columns">
		<?php the_title('<h4>','</h4>');?>			
	</div>
	<div class="breadcrumb-right eight columns">
		<?php if( function_exists('waves_breadcrumbs') ) {
		    waves_breadcrumbs(); 
		  }?>
	</div>
</div>
</div>	
<?php endif; ?>
	</header><!-- #masthead -->
	
	<?php do_action('waves_after_header'); ?>  

