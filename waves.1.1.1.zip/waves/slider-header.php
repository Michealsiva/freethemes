<?php
/**
 * slider header 
 *
 *
 * @package waves
 */
get_header('blank');?>  
<div class="home-header">  
<?php
if( is_front_page() ) {
	if(function_exists('the_custom_header_markup') ) { ?>
	    <div class="custom-header-media">
			<?php the_custom_header_markup(); ?>
		</div>
    <?php }
}
if ( get_theme_mod('page-builder' ) && get_theme_mod('flexslider')  ) { 
	if( is_front_page() ) {	 
	        $header_class ='flex-header';
			echo do_shortcode( get_theme_mod('flexslider'));
	}else {
		$header_class ='flex-header';
		$slider_shortcode = get_post_meta( $post->ID, '_wbls_slider_shortcode', true );
		if( $slider_shortcode != '' ) {
			echo do_shortcode($slider_shortcode);
		}else {      
		   echo do_shortcode( get_theme_mod('flexslider'));
		}
	} 
}
else {   
	if( is_front_page() ) {
		if( get_theme_mod('enable_slider',true) ) {
			$header_class = 'flex-header';  
			get_template_part('category-slider');
		}	
	}else{
		$header_class = 'flex-header';  
		get_template_part('category-slider');
	}
	
}

 $breadcrumb = get_theme_mod( 'breadcrumb' );    
    if( $breadcrumb && !is_front_page() ) : 
	    $header_bread = 'header-bread'; 
	else:   
		$header_bread = '';   
	endif;?>
	
	<header id="masthead" class="site-header <?php echo $header_class; ?>" role="banner">
	<div class="header-wrapper <?php echo $header_bread; ?>">
	<?php if ( get_theme_mod ('header_overlay',false ) ) { 
		   echo '<div class="overlay overlay-header"></div>';     
		} ?>
	<?php if( is_active_sidebar( 'top-left' )  || is_active_sidebar( 'top-left' ) ): ?>
	<div class="top-nav">
			<div class="container">	 	
			<?php if( is_active_sidebar( 'top-left' ) ) : ?>
				<div class="ten columns">
					<div class="cart">
						<?php dynamic_sidebar('top-left' ); ?>
					</div>
				</div>
			<?php endif; ?>
			<?php if( is_active_sidebar('top-right' ) ) : ?>
				<div class="columns six">
					<div class="social">
						<?php dynamic_sidebar('top-right' ); ?>  
					</div>
				</div>
			<?php endif; ?>
			</div>
		</div> <!-- .top-nav -->
	<?php endif;?>
		
		<div class="branding"> 
		<div class="container">
			<div class="six columns">    
				<nav id="site-navigation" class="main-navigation navigation-left clearfix" role="navigation">
					<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><?php echo apply_filters('waves_responsive_left_menu_title',__('Primary Left Menu','waves') ); ?></button>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-left' ) ); ?>   
				</nav><!-- #site-navigation -->
			</div>
			<div class="four columns"> 
				<div class="site-branding">   
					<?php 
						$logo_title = get_theme_mod( 'logo_title' );
						$logo = get_theme_mod( 'logo', '' );
						$tagline = get_theme_mod( 'tagline',true);
						if( $logo_title && function_exists( 'the_custom_logo' ) ) {
                                the_custom_logo();     
					        }elseif( $logo != '' && $logo_title ) { ?>
							   <h1 class="site-title img-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($logo) ?>"></a></h1>
					<?php	}else { ?>
								<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
						    <?php } ?>
					<?php if( $tagline ) : ?>
							<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
					<?php endif; ?>
				</div><!-- .site-branding -->
				
			</div>
			<div class="six columns">    
				<nav id="site-navigation-right" class="main-navigation navigation-right clearfix" role="navigation">
					<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><?php echo apply_filters('waves_responsive_right_menu_title',__('Primary Right Menu','waves') ); ?></button>
					<?php wp_nav_menu( array( 'theme_location' => 'primary-right','menu_class' => 'menu nav-menu' ) ); ?>   
				</nav><!-- #site-navigation -->
			</div>
		</div>
	</div><!-- .branding -->
   </div>
<?php if( !is_front_page() ) : ?>
   <?php $breadcrumb = get_theme_mod( 'breadcrumb' ); ?>    
	<?php if( $breadcrumb ) : ?>
		<div class="breadcrumb">
			<div class="container">
				<div class="breadcrumb-left eight columns">
					<?php the_title('<h4>','</h4>');?>			
				</div>
				<div class="breadcrumb-right eight columns">
					<?php if( function_exists('waves_breadcrumbs') ) {
					    waves_breadcrumbs(); 
					  }?>
				</div>
			</div>
		</div>	
    <?php endif; 
    endif;?>

	</header><!-- #masthead -->

</div>