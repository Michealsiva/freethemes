<?php

function waves_custom_styles($custom) {
$custom = '';	
	$sticky_header_position = get_theme_mod('sticky_header_position');
	if( $sticky_header_position == 'bottom') {
		$custom .= ".sticky-header .branding {  top: auto!important;
			bottom:0; }"."\n";	
		$custom .= ".sticky-header .branding .nav-menu .sub-menu {  top: auto;
			bottom:100%; }"."\n";	
	}	   

     $page_title_bar_status = get_theme_mod('page_titlebar_text');
     if( $page_title_bar_status == 2 ) {
     	    $custom .= " .breadcrumb-left {
     			display: none;
     		}"."\n";
     }

     /* free home page divider */
     $enable_service = get_theme_mod('enable_service');
     $enable_recent_post_service = get_theme_mod('enable_recent_post_service');
     $home_sidebar = get_theme_mod('home_sidebar');
     if( ! $enable_service || ! $enable_recent_post_service ||  $home_sidebar ) {
         $custom .= ".home-top::after {
               display: none;
          }"."\n";
     } 

    $footer_bg_image = get_theme_mod('footer_bg_image');
    $footer_overlay = get_theme_mod('footer_overlay');
     if(  $footer_bg_image ||  $footer_overlay ) {
         $custom .= ".site-footer::before {
               display: none;
          }"."\n";
     } 

    $enable_nav_bg_color = get_theme_mod('enable_nav_bg_color');
   
     if(  $enable_nav_bg_color ) {
         $custom .= ".header-wrapper {
               background-image: none;
          }"."\n";
     } 

    /*  home page header bg image */
    $header_image = get_theme_mod('header_image');
    if(  $header_image == 'remove-header' || ! $header_image ) {
        $custom .= ".home-header .flex-header .header-wrapper {
             background-image: none;
        }"."\n";  
    } 


	//Output all the styles
	wp_add_inline_style( 'waves-style', $custom );    	
}


add_action( 'wp_enqueue_scripts', 'waves_custom_styles' );  
