<?php
/**
 * @package waves
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="entry-content">	
	<?php
		$featured_image = get_theme_mod( 'featured_image',true );
	if( $featured_image ) : ?>
		<div class="post-thumb blog-thumb">
		  <?php
			if( function_exists( 'waves_featured_image' ) ) :
				waves_featured_image();
	        endif;
		  ?>
	    </div>
	<?php endif; ?> 

	<?php do_action('waves_before_entry_header'); ?>

		
	<div class="entry-body-wrapper">
		<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
			<?php do_action('waves_before_entry_header'); ?>
		<header class="entry-header">  
			<?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
					<footer class="entry-meta">
						<?php if(function_exists('waves_entry_top_meta') ) {
						    waves_entry_top_meta(); 
						} ?> 
					</footer><!-- .entry-footer -->
				<?php endif;?> 
             <br class="clear"> 
		</header><!-- .entry-header -->
	
		
<?php do_action('waves_after_entry_header'); ?>
		<?php echo the_content(); 

			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages: ', 'waves' ),
				'after'  => '</div>',
			) );
		?>
	
<?php do_action('waves_before_entry_footer'); ?>
	<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
		<footer class="entry-footer">
			<?php if(function_exists('waves_entry_bottom_meta') ) {
			     waves_entry_bottom_meta();
			} ?>
		</footer><!-- .entry-footer -->
	<?php endif;?>
<?php do_action('waves_after_entry_footer'); ?>

</div>
</div><!-- .entry-content -->


</article><!-- #post-## -->