<?php
/**
 * @package waves
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="entry-content"><?php
$single_featured_image = get_theme_mod( 'single_featured_image',true );
$single_featured_image_size = get_theme_mod ('single_featured_image_size',1);
if ($single_featured_image_size != 3 ) {
	if ( $single_featured_image ) : ?>
		<div class="post-thumb blog-thumb"><?php
		    if( has_post_thumbnail() && ! post_password_required() ) :  
			    if ( $single_featured_image_size == 1 ) :
					the_post_thumbnail('waves-blog-large-width'); 
				else: 
					the_post_thumbnail('waves-small-featured-image-width');	
			    endif; 
			else:
                echo '<img src="' . get_template_directory_uri() . '/images/no-image-blog-full-width.png" />';
		    endif; ?>
		</div><?php
	endif;
} ?>
			  		
	<div class="entry-body-wrapper">
		<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
		<header class="entry-header">  
			<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
		    <div class="entry-meta">
		    <?php if(function_exists('waves_entry_top_meta') ) {
		         waves_entry_top_meta();
		     } ?>
			</div><!-- .entry-meta -->
	<?php endif; ?>
<br class="clear">
	</header><!-- .entry-header -->

	
		<?php echo the_content( __('Readmore', 'waves') ); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages: ', 'waves' ),
				'after'  => '</div>',
			) );
		?>
	
<?php if ( 'post' == get_post_type() ): ?>
<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
	<footer class="entry-footer">
	<?php if(function_exists('waves_entry_bottom_meta') ) {
		     waves_entry_bottom_meta();
		} ?>
	</footer><!-- .entry-footer -->
<?php endif;?>
<?php endif;?>

</div>
</div>
	
</article><!-- #post-## -->
<?php waves_post_nav(); ?> 


