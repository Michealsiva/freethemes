<?php
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */
 
include_once( get_template_directory() . '/admin/kirki/kirki.php' );     
include_once( get_template_directory() . '/admin/kirki-helpers/class-waves-kirki.php' );
        
Waves_Kirki::add_config( 'waves', array(     
	'capability'    => 'edit_theme_options',                  
	'option_type'   => 'theme_mod',         
) );             
     
// Waves option start //   

//  site identity section // 

Waves_Kirki::add_section( 'title_tagline', array(
	'title'          => __( 'Site Identity','waves' ),
	'description'    => __( 'Site Header Options', 'waves'),       
	'priority'       => 8,         																																															
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'logo_title',
	'label'    => __( 'Enable Logo as Title', 'waves' ),
	'section'  => 'title_tagline',
	'type'     => 'switch',
	'priority' => 5,
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',   
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'tagline',
	'label'    => __( 'Show site Tagline', 'waves' ), 
	'section'  => 'title_tagline',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'on',
) );

// home panel //

Waves_Kirki::add_panel( 'home_options', array(     
	'title'       => __( 'Home', 'waves' ),
	'description' => __( 'Home Page Related Options', 'waves' ),     
) );  

// home page type section

Waves_Kirki::add_section( 'home_type_section', array(
	'title'          => __( 'General Settings','waves' ),
	'description'    => __( 'Home Page options', 'waves'),
	'panel'          => 'home_options', // Not typically needed. 
) );


Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_home_default_content',
	'label'    => __( 'Enable Home Page Default Content', 'waves' ),
	'section'  => 'home_type_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	
	'default'  => 'off',
	'tooltip' => __('Enable home page default content ( home page content )','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'home_sidebar',
	'label'    => __( 'Enable sidebar on the Home page', 'waves' ),
	'section'  => 'home_type_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	
	'default'  => 'off',
	'tooltip' => __('Disable by default. If you want to display the sidebars in your frontpage, turn this Enable.','waves'),
) );

// Slider section

Waves_Kirki::add_section( 'slider_section', array(
	'title'          => __( 'Slider Section','waves' ),
	'description'    => __( 'Home Page Slider Related Options', 'waves'),
	'panel'          => 'home_options', // Not typically needed. 
) );
Waves_Kirki::add_field( 'waves', array(  
	'settings' => 'enable_slider',
	'label'    => __( 'Enable Slider Post ( Section ) in home page', 'waves' ),
	'section'  => 'slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ),
	),
	'default'  => 'on',
	'tooltip' => __('Enable Slider Post in home page','waves'),
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'slider_cat',
	'label'    => __( 'Slider Posts category', 'waves' ),
	'section'  => 'slider_section',
	'type'     => 'select',
	'choices' => Kirki_Helper::get_terms( 'category' ),
	'active_callback' => array(
		array(
			'setting'  => 'enable_slider',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'slider_count',
	'label'    => __( 'No. of Sliders', 'waves' ),
	'section'  => 'slider_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 999,
		'step' => 1,
	),
	'default'  => 2,
	'active_callback' => array(
		array(
			'setting'  => 'enable_slider',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','waves'),
) );
Waves_Kirki::add_field( 'waves',array(
	'settings'   =>'global_slider',
	'label'      =>__('Enable to visible slider for all pages','waves'),
	'section'    =>'slider_section',
	'type'       =>'switch',
	'default'    =>'off',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_service',
			'operator' => '==',
			'value'    => true,
		),		
    ), 
));
     
// service section 

Waves_Kirki::add_section( 'service_section', array(
	'title'          => __( 'Service Section','waves' ),
	'description'    => __( 'Home Page - Service Related Options', 'waves'),
	'panel'          => 'home_options', // Not typically needed. 
) );

Waves_Kirki::add_field( 'waves', array( 
	'settings' => 'enable_service',
	'label'    => __( 'Enable Service Section', 'waves' ),
	'section'  => 'service_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	
	'default'  => 'on',
	'tooltip' => __('Enable service section in home page','waves'),
) ); 

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'service_count',
	'label'    => __( 'No. of Service Section', 'waves' ),
	'description' => __('Save the Settings, and Reload this page to Configure the service section','waves'),
	'section'  => 'service_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 4,
		'max' => 99,
		'step' => 4,
	),
	'default'  => 4,
	'active_callback' => array(
		array(
			'setting'  => 'enable_service',
			'operator' => '==',
			'value'    => true,
		),
		
    ),
    'tooltip' => __('Enter number of service page you want to display','waves'),
) );
Waves_Kirki::add_field('waves',array(
	'settings'  =>'service_top_page',
	'label'     =>__( 'Service Top Page', 'waves' ),
	'section'   =>'service_section',
	'type'      =>'dropdown-pages',
	'active_callback' => array(
		array(
			'setting'  => 'enable_service',
			'operator' => '==',
			'value'    => true,
		),
		
	),
));
if ( get_theme_mod('service_count') > 0 ) {
 $service = get_theme_mod('service_count');
 		for ( $i = 1 ; $i <= $service ; $i++ ) {
             //Create the settings Once, and Loop through it.
 			Waves_Kirki::add_field( 'waves', array(
				'settings' => 'service_'.$i,
				'label'    => sprintf(__( 'Service Section #%1$s', 'waves' ), $i ),
				'section'  => 'service_section',
				'type'     => 'dropdown-pages',	
				//'tooltip' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','waves'),
				'active_callback' => array(
					array(
						'setting'  => 'enable_service',
						'operator' => '==',
						'value'    => true,
					),
					
                ), 
               // 'description' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','waves'),
        
			) );
 		}
}

// latest blog section 

Waves_Kirki::add_section( 'latest_blog_section', array(
	'title'          => __( 'Latest Blog Section','waves' ),
	'description'    => __( 'Home Page - Latest Blog Options', 'waves'),
	'panel'          => 'home_options', // Not typically needed. 
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_recent_post_service',
	'label'    => __( 'Enable Recent Post Section', 'waves' ),
	'section'  => 'latest_blog_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	
	'default'  => 'on',
	'tooltip' => __('Enable recent post section in home page','waves'),
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'recent_posts_count',
	'label'    => __( 'No. of Recent Posts', 'waves' ),
	'section'  => 'latest_blog_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 3,
		'max' => 99,
		'step' => 3,
	),
	'default'  => 6,
	'active_callback' => array(
		array(
			'setting'  => 'enable_recent_post_service',
			'operator' => '==',
			'value'    => true,
		),
		
    ),
) );

// general panel   

Waves_Kirki::add_panel( 'general_panel', array(   
	'title'       => __( 'General Settings', 'waves' ),  
	'description' => __( 'general settings', 'waves' ),         
) );

//  Page title bar section // 

Waves_Kirki::add_section( 'header-pagetitle-bar', array(   
	'title'          => __( 'Page Title Bar','waves' ),
	'description'    => __( 'Page Title bar related options', 'waves'),
	'panel'          => 'general_panel', // Not typically needed.
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'page_titlebar_text',  
	'label'    => __( 'Page Title Bar Text', 'waves' ),
	'section'  => 'header-pagetitle-bar', 
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'waves' ),
		2 => __( 'Hide', 'waves' ), 
    ),
    'default' => 1,
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'breadcrumb',  
	'label'    => __( 'Breadcrumb', 'waves' ),
	'section'  => 'header-pagetitle-bar', 
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ),
	),
	'default'  => 'on',
) ); 

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'breadcrumb_char',
	'label'    => __( 'Breadcrumb Character', 'waves' ),
	'section'  => 'header-pagetitle-bar',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( ' >> ', 'waves' ),
		2 => __( ' // ', 'waves' ),
		3 => __( ' > ', 'waves' ),
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'breadcrumb',
			'operator' => '==',
			'value'    => true,
		),
	),
	//'sanitize_callback' => 'allow_htmlentities'
) );

//  scroll to top section  // 

Waves_Kirki::add_section( 'scroll_to_top_section', array(   
	'title'          => __( 'Scroll To Top','waves' ),
	'description'    => __( 'scroll to top option', 'waves'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves',array(
	'settings'  =>'scroll_to_top',
	'label'     =>__('Enable Scroll to Top Button','waves'),
	'section'   =>'scroll_to_top_section',
	'type'      =>'switch',
	'choices'   =>array(
		'on'    =>esc_attr__('Enable','waves'),
		'off'   =>esc_attr__('Disable','waves')
	),
	'default'   =>'off',
));

//  pagination section // 

Waves_Kirki::add_section( 'general-pagination', array(   
	'title'          => __( 'Pagination','waves' ),
	'description'    => __( 'Pagination related options', 'waves'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'numeric_pagination',
	'label'    => __( 'Numeric Pagination', 'waves' ),   
	'section'  => 'general-pagination',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Numbered', 'waves' ),
		'off' => esc_attr__( 'Next/Previous', 'waves' )
	),
	'default'  => 'on',
) );

// skin color panel 

Waves_Kirki::add_panel( 'skin_color_panel', array(   
	'title'       => __( 'Skin Color', 'waves' ),  
	'description' => __( 'Color Settings', 'waves' ),         
) );

// Change Color Options

Waves_Kirki::add_section( 'primary_color_field', array(
	'title'          => __( 'Change Color Options','waves' ),
	'description'    => __( 'This will reflect in links, buttons,Navigation and many others. Choose a color to match your site.', 'waves'),
	'panel'          => 'skin_color_panel', // Not typically needed.
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_primary_color',
	'label'    => __( 'Enable Custom Primary color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#1fb2e2',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'input[type="text"]:focus,ul.filter-options li a,.services-wrapper .service img,.services-wrapper .service span::after,ul.filter-options li a:hover:before, ul.filter-options li .selected:before,.nav-links .nav-previous:hover a:after,.nav-links .nav-next:hover a:after,
						.more-link .nav-next:hover a:after,.flexcarousel-white .widget_flexslider-widget .flex-direction-nav a:hover:after,.portfolio-excerpt .more-link:before,.tabs-container div,.comment-navigation .nav-next:hover a:after,
						.more-link .nav-previous:hover a:after,.left-sidebar .dropcap-book,blockquote:after,.tabs-container ul.tabs li a,.comment-navigation .nav-previous:hover a:after,
						input[type="email"]:focus,.free-home .post-wrapper .latest-post .btn-readmore:hover:before,.flexslider .flex-caption a,.flexslider .flex-caption a:before,
						input[type="url"]:focus,ol.webulous_page_navi .bpn-next-link a:after, ol.webulous_page_navi .bpn-prev-link a:after,
						input[type="password"]:focus,.btn:before,.widget_recent-work-widget ul.filter-options li a:hover:before, .widget_recent-work-widget ul.filter-options li .selected:before,.widget_recent-work-widget ul.filter-options li a,.free-home .services-wrapper .service img,.tabs-container ul.tabs .ui-tabs-active a:before,
						input[type="search"]:focus,.flex-direction-nav a:hover:after,.page-template-blog-fullwidth .hentry.post .entry-title:after, .page-template-blog-large .hentry.post .entry-title:after, .page-template-blog-small .hentry.post .entry-title:after, .single-post .hentry.post .entry-title:after,
						textarea:focus,.free-home .services-wrapper .service span:after,.btn:before,.pullright:after,
						.pullleft:after,.toggle .toggle-content,.circle-icon-box .circle-icon-wrapper .fa-stack i:after,
						.pullnone:after,.circle-icon-box .circle-icon-wrapper .fa-stack i,.icon-polygon .circle-icon-wrapper h3.fa-stack,
						.icon-polygon .circle-icon-wrapper h3.fa-stack:before,.callout-widget a:before, .icon-horizontal .fa-stack i,
						.icon-vertical .fa-stack i,.icon-horizontal .fa-stack i:after,.widget-area h4.widget-title:after,
						.icon-vertical .fa-stack i:after,.widget_image-box-widget .image-box img,.site-footer .widget_tag_cloud a,
						.icon-polygon .circle-icon-wrapper h3.fa-stack:after,.wide-pattern-black .widget_testimonial-widget .flex-direction-nav a:hover:after,
						.widget_button-widget a.btn.btn-default:before,.ui-accordion .ui-accordion-content,.home.blog .hentry.post .entry-title::after, .single-post .hentry.post .entry-title::after,.post-wrapper .latest-post .btn-readmore:hover::before ',
			'property' => 'border-color',
		),
		array(
			'element'  => '.nav-wrap,.free-home .post-wrapper .latest-post .btn-readmore:hover,.woocommerce #content input.button:hover,
							.left-sidebar .dropcap-circle,
							.left-sidebar .dropcap-box,.left-sidebar .widget.widget_skill-widget .skill-container .skill-percentage,
							.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
							.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,
							.site-footer .icon-horizontal .fa-stack,
							.site-footer .icon-vertical .fa-stack,.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
							.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,
							.pullright,.home.blog .hentry.post .entry-title::before, .single-post .hentry.post .entry-title::before,
							.pullleft,.circle-icon-box .circle-icon-wrapper .fa-stack i,
							.pullnone,.circle-icon-box:hover a.more-button,.post-wrapper .latest-post .btn-readmore:hover,
							.tabs-container ul.tabs li a:hover,.ui-accordion .ui-accordion-header-active,
							.main-navigation ul ul li,.free-home .services-wrapper .service .demo-thumb ,.slicknav_menu a:hover,.nav-links .nav-previous:hover a,
							.more-link .nav-previous:hover a,blockquote,.page-template-blog-fullwidth .hentry.post .entry-title:before, .page-template-blog-large .hentry.post .entry-title:before, .page-template-blog-small .hentry.post .entry-title:before, .single-post .hentry.post .entry-title:before ,
							.page-template-blog-fullwidth .more-link,.btn,.dropcap-circle,.withtip:before,.circle-icon-box:hover .circle-icon-wrapper .fa-stack i ,
							.callout-widget a,.wide-pattern-black .widget_testimonial-widget .flex-direction-nav a:hover,
							.dropcap-box,.dropcap-book,.toggle .toggle-title,.toggle .toggle-title .fa,.circle-icon-box a.more-button:hover,
							.widget_button-widget a.btn.btn-default,.flex-direction-nav a:hover,
							.left-sidebar .icon-horizontal .fa-stack,.widget_tag_cloud a,.widget_recent-work-widget ul.filter-options li a:hover, .widget_recent-work-widget ul.filter-options li .selected,
							.left-sidebar .icon-vertical .fa-stack,.icon-horizontal .fa-stack i,
							.icon-vertical .fa-stack i,.share-box ul li a:hover,.widget_image-box-widget a.more-button,.wide-pattern-black .widget_testimonial-widget .flex-direction-nav a:hover,.page-template-blog-large .more-link, .page-template-blog-small .more-link, .single-post .more-link,
							.comment-navigation .nav-previous:hover a,.top-nav ul li:hover a,.tabs-container ul.tabs .ui-tabs-active a,.nav-links .nav-next:hover a,
							.more-link .nav-next:hover a,.hentry.sticky,ol.webulous_page_navi li.bpn-current, ol.webulous_page_navi .bpn-next-link a, ol.webulous_page_navi .bpn-prev-link a,ol.webulous_page_navi li a:hover,.comment-navigation .nav-next:hover a,a.more-link:hover,a.more-link:hover .meta-nav,
							.woocommerce #content div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce-page div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce #content div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce-page div.product .woocommerce-tabs ul.tabs li.active,.woocommerce #content nav.woocommerce-pagination ul li a:focus,
							.woocommerce #content nav.woocommerce-pagination ul li a:hover,
							.woocommerce #content nav.woocommerce-pagination ul li span.current,
							.woocommerce nav.woocommerce-pagination ul li a:focus,
							.woocommerce nav.woocommerce-pagination ul li a:hover,
							.woocommerce nav.woocommerce-pagination ul li span.current,
							.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
							.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,
							.woocommerce-page #content nav.woocommerce-pagination ul li span.current,
							.woocommerce-page nav.woocommerce-pagination ul li a:focus,
							.woocommerce-page nav.woocommerce-pagination ul li a:hover,
							.woocommerce-page nav.woocommerce-pagination ul li span.current,.woocommerce a.remove,
							.widget_search .search-form input[type="submit"],#secondary .left-sidebar .widget .sidebar-title-wrapper h4.widget-title,
							#secondary .left-sidebar .widget .sidebar-title-wrapper::before,.site-footer .scroll-to-top',
			'property' => 'background-color',
		),
		/*array(
			'element'  => '.main-navigation a:hover::after,
							 .main-navigation .current_page_item > a::after,
							 .main-navigation .current-menu-item > a::after,
							 .main-navigation .current_page_ancestor > a::after,
							 .main-navigation .current_page_parent > a::after,.widget_magazine-post-boxed-widget .entry-content .cat-links a::after,.widget_magazine-post-boxed-widget .mag-divider::after ',
			'property' => 'border-left-color',
		),*/
		array(
			'element'  => 'a,.main-navigation ul ul a,.widget-area ul li a:hover,.site-info .widget_nav_menu a:hover,.site-info p a,.widget_calendar table th a,.widget-area .widget_rss a,.widget_calendar table td a,
							#secondary #recentcomments a,.main-navigation .current_page_item,.widget_list-widget ul li .fa, .widget_list-widget ol li .fa,
							.main-navigation .current-menu-item,.widget_testimonial-widget ul li p.client,.widget_recent-posts-widget .entry-meta span:hover i, .widget_recent-posts-widget .entry-meta span:hover a,
							.main-navigation .current_page_ancestor,.main-navigation .current_page_item > a,.widget_recent-posts-widget .entry-meta span:hover,
							.main-navigation .current-menu-item > a,.circle-icon-box:hover h4,.widget_recent-posts-widget h4 a:hover,#secondary .btn-white:hover,
							#secondary .widget_button-widget .btn.white:hover,.site-footer .footer-widgets a:hover,.site-footer .widget_recent-posts-widget li .recent-post:hover h4 a,
							.main-navigation .current_page_ancestor > a,.main-navigation .sub-menu .current_page_item,.site-footer .footer-bottom ul.menu li a:hover,
							.main-navigation .sub-menu .current-menu-item,.woocommerce #content table.cart a.remove,.left-sidebar .widget_social-networks-widget ul li a:hover i,
							.woocommerce table.cart a.remove,.contact-info .textwidget a:hover, .contact-info p a:hover,.site-footer .icon-horizontal .icon-title,
							.site-footer .icon-vertical .icon-title,.site-footer .widget_list-widget ul li i,.site-footer .widget_testimonial-widget ul li .client,
							.circle-icon-box:hover a.link-title,.site-footer .widget.widget_ourteam-widget:hover .team-content h4,
							.main-navigation .sub-menu .current_page_ancestor,.main-navigation ul.nav-menu > li a:hover ,.site-footer .footer-widgets #calendar_wrap a,
							.main-navigation .children .current_page_item,.main-navigation .sub-menu li a:hover, .main-navigation .children li a:hover,
							.main-navigation .children-menu .current-menu-item,.hentry.post h1 a:hover,.entry-meta span:hover i,
							.main-navigation .children-menu .current_page_ancestor,.main-navigation .sub-menu .current_page_item > a,
							.main-navigation .sub-menu .current-menu-item > a,.services-wrapper .service:hover h4,.breadcrumb a,.nav-links .nav-previous:hover a .meta-nav,.entry-footer span:hover i,
							.more-link .nav-previous:hover a .meta-nav, .comment-navigation .nav-previous:hover a .meta-nav,.comment-metadata a:hover,
							.main-navigation .sub-menu .current_page_ancestor > a,.alert-message a:hover,.widget_recent-work-widget .portfolioeffects .content-details h3 a:hover, .widget_recent-work-widget .work .content-details h3 a:hover,.page-links a ,.free-home .post-wrapper .latest-post h3 a:hover,.top-nav .social ul li:hover a,ol.comment-list .reply:before,
							.main-navigation .children .current_page_item > a,.order-total .amount,.widget.widget_ourteam-widget .team-social ul li a:hover,
							.cart-subtotal .amount,.nav-links .nav-next:hover a .meta-nav,ol.comment-list article .fn ,
							.more-link .nav-next:hover a .meta-nav, .comment-navigation .nav-next:hover a .meta-nav,.entry-meta span:hover a,ul#portfolio li h3 a:hover,
							.main-navigation .children .current-menu-item > a,.post-wrapper .latest-post .entry-meta span:hover i, .post-wrapper .latest-post .entry-meta span:hover a,.left-sidebar .icon-horizontal .icon-title,
							.left-sidebar .icon-vertical .icon-title,.left-sidebar .dropcap,#secondary .left-sidebar .widget.widget_ourteam-widget .team-content h4,.portfolioeffects .content-details h3 a:hover,.portfolioeffects .overlay_icon a:hover i ,
							.entry-footer span:hover a,.branding .site-branding a:hover,.single-post .edit-link:hover,.left-sidebar .widget_recent-posts-widget .flex-recent-posts li a ,.left-sidebar .widget_list-widget ul li i,.page-template-blog-large .edit-link:hover,
							.main-navigation .children .current_page_ancestor > a,.post-wrapper .latest-post .entry-meta span:hover,.post-wrapper .latest-post h3 a:hover,.free-home .post-wrapper .latest-post .entry-meta span:hover i, .free-home .post-wrapper .latest-post .entry-meta span:hover a,.free-home .post-wrapper .latest-post .entry-meta span:hover,.free-home .services-wrapper .service:hover h4,
							.order-total .amount,
							.cart-subtotal .amount,.woocommerce #content table.cart a.remove,
							.woocommerce table.cart a.remove,
							.woocommerce-page #content table.cart a.remove,
							.woocommerce-page table.cart a.remove,.woocommerce .woocommerce-breadcrumb a:hover,
							.woocommerce-page .woocommerce-breadcrumb a:hover,.star-rating',
			'property' => 'color',
		),
		/*array(
			'element'  => 'th a,
							.left-sidebar #recentcomments a,
							#recentcomments a,
							.left-sidebar .widget_rss a,
							.widget_tag_cloud a:hover,.widget_magazine-featured-slider-widget .magazine-featured-slider-wrapper .flexslider .slides .flex-caption a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element'  => '.woocommerce #content input.button:hover,
							.woocommerce #respond input#submit:hover,
							.woocommerce a.button:hover,
							.woocommerce button.button:hover,
							.woocommerce input.button:hover,
							.woocommerce-page #content input.button:hover,
							.woocommerce-page #respond input#submit:hover,
							.woocommerce-page a.button:hover,
							.woocommerce-page button.button:hover,
							.woocommerce-page input.button:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => '.sep:after,.withtip.top:after ',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.withtip.bottom:after,.widget-area h4.widget-title',
			'property' => 'border-bottom-color',
		),
		array(
			'element' => '.tabs-container ul.tabs:after,.withtip.right:after,.icon-polygon .circle-icon-wrapper h3.fa-stack ',
			'property' => 'border-right-color',
		),
		array(
			'element' => '.tabs-container ul.tabs li:first-child:after,.withtip.left:after,.icon-polygon .circle-icon-wrapper h3.fa-stack',
			'property' => 'border-left-color',
		),
	),
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_nav_bg_color',
	'label'    => __( 'Enable Navigation Bar BG Color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'nav_bg_color',
	'label'    => __( 'Navigation Bar BG Color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#000',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_nav_bg_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.header-wrapper',
			'property' => 'background-color',
		),
	),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_nav_hover_color',
	'label'    => __( 'Enable Navigation Hover color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );    
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'nav_hover_color',
	'label'    => __( 'Navigation Hover Color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#1fb2e2',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_nav_hover_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.main-navigation .current_page_item > a,.main-navigation .sub-menu li a:hover,.main-navigation ul.nav-menu > li a:hover,.main-navigation .children li a:hover,.main-navigation .sub-menu .current_page_item > a, .main-navigation .sub-menu .current-menu-item > a, .main-navigation .sub-menu .current_page_ancestor > a, .main-navigation .children .current_page_item > a, .main-navigation .children .current-menu-item > a, .main-navigation .children .current_page_ancestor > a,.current-menu-parent a ,.main-navigation .current-menu-item > a, .main-navigation .current_page_ancestor > a,.main-navigation ul.nav-menu > li a:hover,.main-navigation ul.nav-menu > li a:hover',
			'property' => 'color',
		),
	),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_dd_bg_color',
	'label'    => __( 'Enable Custom Navigation Dropdown Background color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );    
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'dd_bg_color',
	'label'    => __( 'Custom Navigation Dropdown Background color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#fff',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_dd_bg_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.main-navigation .sub-menu, .main-navigation .children',
			'property' => 'background-color',
		),
	),
) );
/*Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_secondary_color',
	'label'    => __( 'Enable Custom Secondary color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#222222',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.not-found-inner a:hover,
							.footer-bottom p a:hover,
							.entry-meta span a:hover,
							.entry-footer span a:hover,
							#secondary .widget_rss .widget-title .rsswidget,
							.footer-top ul li a,
							.more-link .meta-nav,
							.error-404.not-found,
							a.more-link,
							.site-main .comment-navigation a:hover,
							a:hover,
							a:focus,
							a:active,
							.comment-list > li article .reply:hover i,
							.comment-list > li article .comment-meta .comment-author b:hover,
							.comment-list > li article .comment-meta .comment-author a:hover,
							.comment-list > li article .comment-meta .comment-author cite:hover,
							.widget_calendar table th a:hover,
							.widget_calendar table td a:hover',
			'property' => 'color',
		),
		array(
			'element' => 'th a:hover,
							#recentcomments a:hover,
							.left-sidebar .widget_rss a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element' => '.home .flexslider .slides .flex-caption p a:hover,
							.home .flexslider .slides .flex-caption a:hover,
							.footer-widgets .textwidget .wpcf7-form input.wpcf7-submit:hover,
							.site-header .branding .social .widget .textwidget li a,
							.share-box ul li a,
							.site-footer .widget_social-networks-widget ul li a:hover,
							.site-footer .search-form input.search-submit:hover,
							.site-footer .search-form input[type="submit"]:hover',
			'property' => 'background-color',
		),
       array(
			'element' => '.flexslider .slides .flex-caption p a::after',
			'property' => 'border-left-color',
			'suffix' => '!important',
		),
        array(
			'element' => '.social .widget_social-networks-widget ul li a::after',
			'property' => 'border-top-color',
		),
	),
) );*/
// typography panel //

Waves_Kirki::add_panel( 'typography', array( 
	'title'       => __( 'Typography', 'waves' ),
	'description' => __( 'Typography and Link Color Settings', 'waves' ),
) );
   
    Waves_Kirki::add_section( 'typography_section', array(
		'title'          => __( 'General Settings','waves' ),
		'description'    => __( 'General Settings', 'waves'),
		'panel'          => 'typography', // Not typically needed.
	) );
	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'custom_typography',
		'label'    => __( 'Enable Custom Typography', 'waves' ),
		'description' => __('Save the Settings, and Reload this page to Configure the typography section','waves'),
		'section'  => 'typography_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'waves' ),
			'off' => esc_attr__( 'Disable', 'waves' )
		),
		'tooltip' => __('Turn on to customize typography and turn off for default typography','waves'),
		'default'  => 'off',
	) );

$typography_setting = get_theme_mod('custom_typography',false );
if( $typography_setting ) :

        $body_font = get_theme_mod('body_family','Play');		        
	    $body_color = get_theme_mod( 'body_color','#333333' );
		$body_size = get_theme_mod( 'body_size','16');
		$body_weight = get_theme_mod( 'body_weight','normal');
		$body_weight == 'bold' ? $body_weight = '700':  $body_weight = 'regular';
		

	Waves_Kirki::add_section( 'body_font', array(
		'title'          => __( 'Body Font','waves' ),
		'description'    => __( 'Specify the body font properties', 'waves'),
		'panel'          => 'typography', // Not typically needed.
	) ); 


	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'body',
		'label'    => __( 'Body Settings', 'waves' ),
		'section'  => 'body_font', 
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $body_font,
			'variant'        => $body_weight,
			'font-size'      => $body_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $body_color,
		),
		'output'      => array(
			array(
				'element' => 'body',
				//'suffix' => '!important',
			),
		),
	) );


	Waves_Kirki::add_section( 'heading_section', array(
		'title'          => __( 'Heading Font','waves' ),
		'description'    => __( 'Specify typography of h1,h2,h3,h4,h5,h6', 'waves'),
		'panel'          => 'typography', // Not typically needed.
	) );
	

	$h1_font = get_theme_mod('h1_family','Anton');
	$h1_color = get_theme_mod ( 'h1_color','#333333' );
	$h1_size = get_theme_mod( 'h1_size','48');
	$h1_weight = get_theme_mod( 'h1_weight','700');
	$h1_weight == 'bold' ? $h1_weight = '700' : $h1_weight = 'regular';

	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'h1',
		'label'    => __( 'H1 Settings', 'waves' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h1_font,
			'variant'        => $h1_weight,
			'font-size'      => $h1_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h1_color,
		),
		'output'      => array(
			array(
				'element' => 'h1',
			),
		),
	
	) );

	$h2_font = get_theme_mod('h2_family','Anton');
	$h2_color = get_theme_mod( 'h2_color','#333333' );
	$h2_size = get_theme_mod( 'h2_size','36');
	$h2_weight = get_theme_mod( 'h2_weight','700');
	$h2_weight == 'bold' ? $h2_weight = '700' : $h2_weight = 'regular';

	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'h2',
		'label'    => __( 'H2 Settings', 'waves' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h2_font,
			'variant'        => $h2_weight,
			'font-size'      => $h2_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h2_color,
		),
		'output'      => array(
			array(
				'element' => 'h2',
			),
		),
		
	) );

	$h3_font = get_theme_mod('h3_family','Anton');
	$h3_color = get_theme_mod( 'h3_color','#333333' );
	$h3_size = get_theme_mod( 'h3_size','30');
	$h3_weight = get_theme_mod( 'h3_weight','700');
	$h3_weight == 'bold' ? $h3_weight = '700' : $h3_weight = 'regular';

	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'h3',
		'label'    => __( 'H3 Settings', 'waves' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default' => array(
			'font-family'    => $h3_font,
			'variant'        => $h3_weight,
			'font-size'      => $h3_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h3_color,
		),
		'output'      => array(
			array(
				'element' => 'h3',
			),
		),
		
	) );

	$h4_font = get_theme_mod('h4_family','Anton');
	$h4_color = get_theme_mod( 'h4_color','#333333' );
	$h4_size = get_theme_mod( 'h4_size','24');
	$h4_weight = get_theme_mod( 'h4_weight','700');
	$h4_weight == 'bold' ? $h4_weight = '700' : $h4_weight = 'regular';


	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'h4',
		'label'    => __( 'H4 Settings', 'waves' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h4_font,
			'variant'        => $h4_weight,
			'font-size'      => $h4_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h4_color,
		),
		'output'      => array(
			array(
				'element' => 'h4',
			),
		),
	
	) );

    $h5_font = get_theme_mod('h5_family','Anton');
	$h5_color = get_theme_mod( 'h5_color','#333333' );
	$h5_size = get_theme_mod( 'h5_size','18');
	$h5_weight = get_theme_mod( 'h5_weight','700');
	$h5_weight == 'bold' ? $h5_weight = '700' : $h5_weight = 'regular';


	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'h5',
		'label'    => __( 'H5 Settings', 'waves' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h5_font,
			'variant'        => $h5_weight,
			'font-size'      => $h5_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h5_color,
		),
		'output'      => array(
			array(
				'element' => 'h5',
			),
		),
		
	) );

	$h6_font = get_theme_mod('h6_family','Anton');
	$h6_color = get_theme_mod( 'h6_color','#333333' );
	$h6_size = get_theme_mod( 'h6_size','16');
	$h6_weight = get_theme_mod( 'h6_weight','700');
	$h6_weight == 'bold' ? $h6_weight = '700' : $h6_weight = 'regular';


	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'h6',
		'label'    => __( 'H6 Settings', 'waves' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h6_font,
			'variant'        => $h6_weight,
			'font-size'      => $h6_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h6_color,
		),
		'output'      => array(
			array(
				'element' => 'h6',
			),
		),
		
	) );

	// navigation font 
	Waves_Kirki::add_section( 'navigation_section', array(
		'title'          => __( 'Navigation Font','waves' ),
		'description'    => __( 'Specify Navigation font properties', 'waves'),
		'panel'          => 'typography', // Not typically needed.
	) );

	Waves_Kirki::add_field( 'waves', array(
		'settings' => 'navigation_font',
		'label'    => __( 'Navigation Font Settings', 'waves' ),
		'section'  => 'navigation_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => 'Play',
			'variant'        => '700',
			'font-size'      => '16px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => '#ffffff',
		),
		'output'      => array(
			array(
				'element' => '.main-navigation a',
			),
		),
	) );
endif; 


// header panel //

Waves_Kirki::add_panel( 'header_panel', array(     
	'title'       => __( 'Header', 'waves' ),
	'description' => __( 'Header Related Options', 'waves' ), 
) );  

/*Waves_Kirki::add_section( 'header', array(
	'title'          => __( 'General Header','waves' ),
	'description'    => __( 'Header options', 'waves'),
	'panel'          => 'header_panel', // Not typically needed.  
) );    

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_text_color',
	'label'    => __( 'Header Text Color', 'waves' ),
	'section'  => 'header',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#ffffff', 
	'output'   => array(
		array(
			'element'  => '.main-navigation a,.site-header .branding .site-branding .site-title a,.main-navigation ul ul a,.main-navigation a:hover, .main-navigation .current_page_item > a, .main-navigation .current-menu-item > a, .main-navigation .current-menu-parent > a, .main-navigation .current_page_ancestor > a, .main-navigation .current_page_parent > a',
			'property' => 'color',
		),
	),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_search',
	'label'    => __( 'Enable to Show Search box in Header', 'waves' ), 
	'section'  => 'header',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'on',
) );*/
/* Breaking News section  */
/*Waves_Kirki::add_section( 'header_breaking_news', array(
	'title'          => __( 'Breaking News','waves' ),
	'description'    => __( 'Breaking News', 'waves'),
	'panel'          => 'header_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_breaking_news',
	'label'    => __( 'Enable Breaking News', 'waves' ), 
	'section'  => 'header_breaking_news',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'active_callback' => array(
		array(
			'setting'  => 'home-page-type',
			'operator' => '==',
			'value'    => 'magazine',
		),
    ),
	'default'  => 'off',
) );*/
/* STICKY HEADER section */   

Waves_Kirki::add_section( 'header_slider_section', array(
	'title'          => __( 'Header','waves' ),  
	'description'    => __( 'slider header type', 'waves'),
	'panel'          => 'header_panel', // Not typically needed.
) );

Waves_Kirki::add_field( 'waves',array(
	'settings'  =>'header_slider_type',
	'label'     =>__('Choose Header Type For Slider Pages','waves'),
	'section'   =>'header_slider_section',
	'type'      =>'radio-buttonset',
	'choices'   =>array(
		'ahead'    =>esc_attr__('Ahead Slider','waves'),  
		'below'   =>esc_attr__('Below Slider','waves')
	),   
	'default'   =>'ahead',
	'tooltip' => __('Choose header type for slider pages','waves'),
));

Waves_Kirki::add_field( 'waves',array(
	'settings'  =>'header_top_height',
	'label'     =>__('Choose Header Top Height','waves'),
	'section'   =>'header_slider_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 0,
		'max' => 999,
		'step' => 1,
	), 
	'output' => array(
		array(
			'element' => '.header-wrapper',
			'property' => 'padding-top',
			'suffix' => 'px',
		),
	), 
	'default'   => 80,
));

Waves_Kirki::add_section( 'sticky_header', array(
	'title'          => __( 'Sticky Menu','waves' ),
	'description'    => __( 'sticky header', 'waves'),
	'panel'          => 'header_panel', // Not typically needed.
) );

Waves_Kirki::add_field( 'waves', array(    
	'settings' => 'sticky_header',
	'label'    => __( 'Enable Sticky Header', 'waves' ),
	'section'  => 'sticky_header',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'sticky_header_position',
	'label'    => __( 'Enable Sticky Header Position', 'waves' ),
	'section'  => 'sticky_header',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'top'  => esc_attr__( 'Top', 'waves' ),
		'bottom' => esc_attr__( 'Bottom', 'waves' )
	),
	'active_callback'    => array(
		array(
			'setting'  => 'sticky_header',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'top',
) );
/*
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_top_margin',
	'label'    => __( 'Header Top Margin', 'waves' ),
	'description' => __('Select the top margin of header in pixels','waves'),
	'section'  => 'header',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1,
	),
	//'default'  => '213',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_bottom_margin',
	'label'    => __( 'Header Bottom Margin', 'waves' ),
	'description' => __('Select the bottom margin of header in pixels','waves'),
	'section'  => 'header',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1,
	),
	//'default'  => '213',
) );*/

Waves_Kirki::add_section( 'header_image', array(
	'title'          => __( 'Header Background Image & Video','waves' ),
	'description'    => __( 'Custom Header Image & Video options', 'waves'),
	'panel'          => 'header_panel', // Not typically needed.  
) );

Waves_Kirki::add_field( 'waves', array(   
	'settings' => 'header_bg_size',
	'label'    => __( 'Header Background Size', 'waves' ),
	'section'  => 'header_image',
	'type'     => 'radio-buttonset', 
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'waves' ),
		'contain' => esc_attr__( 'Contain', 'waves' ),
		'auto'  => esc_attr__( 'Auto', 'waves' ),
		'inherit'  => esc_attr__( 'Inherit', 'waves' ),
	),
	'output'   => array(
		array(
			'element'  => '.header-wrapper',
			'property' => 'background-size',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Header Background Image Size','waves'),
) );

/*Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_height',
	'label'    => __( 'Header Background Image Height', 'waves' ),
	'section'  => 'header_image',
	'type'     => 'number',
	'choices' => array(
		'min' => 100,
		'max' => 600,
		'step' => 1,
	),
	'default'  => '213',
) ); */
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_bg_repeat',
	'label'    => __( 'Header Background Repeat', 'waves' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'waves'),
        'repeat' => esc_attr__('Repeat', 'waves'),
        'repeat-x' => esc_attr__('Repeat Horizontally','waves'),
        'repeat-y' => esc_attr__('Repeat Vertically','waves'),
	),
	'output'   => array(
		array(
			'element'  => '.header-image',
			'property' => 'background-repeat',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'repeat',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_bg_position', 
	'label'    => __( 'Header Background Position', 'waves' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'waves'),
        'center center' => esc_attr__('Center Center', 'waves'),
        'center bottom' => esc_attr__('Center Bottom', 'waves'),
        'left top' => esc_attr__('Left Top', 'waves'),
        'left center' => esc_attr__('Left Center', 'waves'),
        'left bottom' => esc_attr__('Left Bottom', 'waves'),
        'right top' => esc_attr__('Right Top', 'waves'),
        'right center' => esc_attr__('Right Center', 'waves'),
        'right bottom' => esc_attr__('Right Bottom', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => '.header-image',
			'property' => 'background-position',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'center center',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_bg_attachment',
	'label'    => __( 'Header Background Attachment', 'waves' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'waves'),
        'fixed' => esc_attr__('Fixed', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => '.header-image',
			'property' => 'background-attachment',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'scroll',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_overlay',
	'label'    => __( 'Enable Header( Background ) Overlay', 'waves' ),
	'section'  => 'header_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );
  
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'header_overlay_color',
	'label'    => __( 'Header Overlay ( Background )color', 'waves' ),
	'section'  => 'header_image',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#E5493A', 
	'output'   => array(
		array(
			'element'  => '.overlay-header,.sticky-header .branding',
			'property' => 'background-color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
) );

/*
/* e-option start */
/*
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'custon_favicon',
	'label'    => __( 'Custom Favicon', 'waves' ),
	'section'  => 'header',
	'type'     => 'upload',
	'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Waves_Kirki::add_panel( 'blog_panel', array(     
	'title'       => __( 'Blog', 'waves' ),
	'description' => __( 'Blog Related Options', 'waves' ),     
) ); 
Waves_Kirki::add_section( 'blog', array(
	'title'          => __( 'Blog Page','waves' ),
	'description'    => __( 'Blog Related Options', 'waves'),
	'panel'          => 'blog_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'blog-slider',
	'label'    => __( 'Enable to show the slider on blog page', 'waves' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'off',
	'tooltip' => __('To show the slider on posts page','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'blog_layout',
	'label'    => __( 'Select Blog Page Layout you prefer', 'waves' ),
	'section'  => 'blog',
	'type'     => 'select',
	'multiple'  => 1,
	'choices' => array(
		1  => esc_attr__( 'Default ( One Column )', 'waves' ),
		2 => esc_attr__( 'Two Columns ', 'waves' ),
		3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'waves' ),
		4 => esc_attr__( 'Two Columns With Masonry', 'waves' ),
		5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'waves' ),
	),
	'default'  => 1,
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'featured_image',
	'label'    => __( 'Enable Featured Image', 'waves' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable Featured Image for blog page','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'more_text',
	'label'    => __( 'More Text', 'waves' ),
	'section'  => 'blog',
	'type'     => 'text',
	'description' => __('Text to display in case of text too long','waves'),
	'default' => __('Read More','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'featured_image_size',
	'label'    => __( 'Choose the Featured Image Size for Blog Page', 'waves' ),
	'section'  => 'blog',
	'type'     => 'select',
	'multiple'  => 1,
	'choices' => array(
		1 => esc_attr__( 'Large Featured Image', 'waves' ),
		2 => esc_attr__( 'Small Featured Image', 'waves' ),
		3 => esc_attr__( 'Original Size', 'waves' ),
		4 => esc_attr__( 'Medium', 'waves' ),
		5 => esc_attr__( 'Large', 'waves' ), 
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'waves') ,
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_single_post_top_meta',
	'label'    => __( 'Enable to display top post meta data', 'waves' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'single_post_top_meta',
	'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'waves' ),
	'section'  => 'blog',
	'type'     => 'sortable',
	'choices'     => array(
		1 => esc_attr__( 'date', 'waves' ),
		2 => esc_attr__( 'author', 'waves' ),
		3 => esc_attr__( 'comment', 'waves' ),
		4 => esc_attr__( 'category', 'waves' ),
		5 => esc_attr__( 'tags', 'waves' ),
		6 => esc_attr__( 'edit', 'waves' ),
	),
	'default'  => array(1, 2, 6),
	'active_callback' => array(
		array(
			'setting'  => 'enable_single_post_top_meta',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','waves'),

) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'enable_single_post_bottom_meta',
	'label'    => __( 'Enable to display bottom post meta data', 'waves' ),
	'section'  => 'blog', 
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','waves'),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'single_post_bottom_meta',
	'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'waves' ),
	'section'  => 'blog',
	'type'     => 'sortable',
	'choices'     => array(
		1 => esc_attr__( 'date', 'waves' ),
		2 => esc_attr__( 'author', 'waves' ),
		3 => esc_attr__( 'comment', 'waves' ),
		4 => esc_attr__( 'category', 'waves' ),
		5 => esc_attr__( 'tags', 'waves' ),
		6 => esc_attr__( 'edit', 'waves' ),
	),
	'default'  => array(3,4,5),
	'active_callback' => array(
		array(
			'setting'  => 'enable_single_post_bottom_meta',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','waves'),
) );


/* Single Blog page section */

Waves_Kirki::add_section( 'single_blog', array(
	'title'          => __( 'Single Blog Page','waves' ),
	'description'    => __( 'Single Blog Page Related Options', 'waves'),
	'panel'          => 'blog_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'single_featured_image',
	'label'    => __( 'Enable Single Post Featured Image', 'waves' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable Featured Image for Single Post Page','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'single_featured_image_size',
	'label'    => __( 'Choose the featured image display type for Single Post Page', 'waves' ),
	'section'  => 'single_blog',
	'type'     => 'radio',
	'choices' => array(
		1  => esc_attr__( 'Large Featured Image', 'waves' ),
		2 => esc_attr__( 'Small Featured Image', 'waves' ),
		3 => esc_attr__( 'FullWidth Featured Image', 'waves' ),
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'single_featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'social_sharing_box',
	'label'    => __( 'Enable Social Sharing options Box below single post', 'waves' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'author_bio_box',
	'label'    => __( 'Enable Author Bio Box below single post', 'waves' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'related_posts',
	'label'    => __( 'Show Related Posts', 'waves' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'off',
	'tooltip' => __('Show the Related Post for Single Blog Page','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'related_posts_hierarchy',
	'label'    => __( 'Related Posts Must Be Shown As:', 'waves' ),
	'section'  => 'single_blog',
	'type'     => 'radio',
	'choices' => array(
		1  => esc_attr__( 'Related Posts By Tags', 'waves' ),
		2 => esc_attr__( 'Related Posts By Categories', 'waves' ) 
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'related_posts',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Select the Hierarchy','waves'),

) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'comments',
	'label'    => __( ' Show Comments', 'waves' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Show the Comments for Single Blog Page','waves'),
) );
/* FOOTER SECTION 
footer panel */

Waves_Kirki::add_panel( 'footer_panel', array(     
	'title'       => __( 'Footer', 'waves' ),
	'description' => __( 'Footer Related Options', 'waves' ),     
) );  

Waves_Kirki::add_section( 'footer', array(
	'title'          => __( 'Footer','waves' ),
	'description'    => __( 'Footer related options', 'waves'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_widgets',
	'label'    => __( 'Footer Widget Area', 'waves' ),
	'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','waves'),admin_url('customize.php') ),
	'section'  => 'footer',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );
/* Choose No.Of Footer area */
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_widgets_count',
	'label'    => __( 'Choose No.of widget area you want in footer', 'waves' ),
	'section'  => 'footer',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( '1', 'waves' ),
		2  => esc_attr__( '2', 'waves' ),
		3  => esc_attr__( '3', 'waves' ),
		4  => esc_attr__( '4', 'waves' ),
	),
	'default'  => 4,
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'copyright',
	'label'    => __( 'Footer Copyright Text', 'waves' ),
	'section'  => 'footer',
	'type'     => 'textarea',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_top_margin',
	'label'    => __( 'Footer Top Margin', 'waves' ),
	'description' => __('Select the top margin of footer in pixels','waves'),
	'section'  => 'footer',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.site-footer',
			'property' => 'margin-top',
			'units' => 'px',
		),
	),
	'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Waves_Kirki::add_section( 'footer_image', array(
	'title'          => __( 'Footer Image','waves' ),
	'description'    => __( 'Custom Footer Image options', 'waves'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_image',
	'label'    => __( 'Upload Footer Background Image', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-image',
		),
	),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_size',
	'label'    => __( 'Footer Background Size', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'radio-buttonset',
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'waves' ),
		'contain' => esc_attr__( 'Contain', 'waves' ),
		'auto'  => esc_attr__( 'Auto', 'waves' ),
		'inherit'  => esc_attr__( 'Inherit', 'waves' ),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Footer Background Image Size','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_repeat',
	'label'    => __( 'Footer Background Repeat', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'waves'),
        'repeat' => esc_attr__('Repeat', 'waves'),
        'repeat-x' => esc_attr__('Repeat Horizontally','waves'),
        'repeat-y' => esc_attr__('Repeat Vertically','waves'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_position',
	'label'    => __( 'Footer Background Position', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'waves'),
        'center center' => esc_attr__('Center Center', 'waves'),
        'center bottom' => esc_attr__('Center Bottom', 'waves'),
        'left top' => esc_attr__('Left Top', 'waves'),
        'left center' => esc_attr__('Left Center', 'waves'),
        'left bottom' => esc_attr__('Left Bottom', 'waves'),
        'right top' => esc_attr__('Right Top', 'waves'),
        'right center' => esc_attr__('Right Center', 'waves'),
        'right bottom' => esc_attr__('Right Bottom', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'center center',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_attachment',
	'label'    => __( 'Footer Background Attachment', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'waves'),
        'fixed' => esc_attr__('Fixed', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'scroll',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_overlay',
	'label'    => __( 'Enable Footer( Background ) Overlay', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );
  
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_overlay_color',
	'label'    => __( 'Footer Overlay ( Background )color', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#E5493A', 
	'active_callback' => array(
		array(
			'setting'  => 'footer_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output'   => array(
		array(
			'element'  => '.overlay-footer',
			'property' => 'background-color',
		),
	),
) );


// single page section //

Waves_Kirki::add_section( 'single_page', array(
	'title'          => __( 'Single Page','waves' ),
	'description'    => __( 'Single Page Related Options', 'waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'single_page_featured_image',
	'label'    => __( 'Enable Single Page Featured Image', 'waves' ),
	'section'  => 'single_page',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'single_page_featured_image_size',
	'label'    => __( 'Single Page Featured Image Size', 'waves' ),
	'section'  => 'single_page',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( 'Normal', 'waves' ),
		2 => esc_attr__( 'FullWidth', 'waves' ) 
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'single_page_featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

// Layout section //

Waves_Kirki::add_section( 'layout', array(
	'title'          => __( 'Layout','waves' ),
	'description'    => __( 'Layout Related Options', 'waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'site-style',
	'label'    => __( 'Site Style', 'waves' ),
	'section'  => 'layout',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'wide' =>  esc_attr__('Wide', 'waves'),
        'boxed' =>  esc_attr__('Boxed', 'waves'),
        'fluid' =>  esc_attr__('Fluid', 'waves'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'waves'),
    ),
	'default'  => 'wide',
	'tooltip' => __('Select the default site layout. Defaults to "Wide".','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'sidebar_position',
	'label'    => __( 'Main Layout', 'waves' ),
	'section'  => 'layout',
	'type'     => 'radio-image',   
	'description' => __('Select main content and sidebar arranwavesent.','waves'),
	'choices' => array(
		'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
	'default'  => 'right',
	'tooltip' => __('This layout will be reflected in all pages unless unique layout template is set for specific page','waves'),
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'body_top_margin',
	'label'    => __( 'Body Top Margin', 'waves' ),
	'description' => __('Select the top margin of body element in pixels','waves'),
	'section'  => 'layout',
	'type'     => 'number',
	'choices' => array(
		'min' => 0,
		'max' => 200,
		'step' => 1,
	),
	'active_callback'    => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'margin-top',
			'units'    => 'px',
		),
	),
	'default'  => 0,
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'body_bottom_margin',
	'label'    => __( 'Body Bottom Margin', 'waves' ),
	'description' => __('Select the bottom margin of body element in pixels','waves'),
	'section'  => 'layout',
	'type'     => 'number',
	'choices' => array(
		'min' => 0,
		'max' => 200,
		'step' => 1,
	),
	'active_callback'    => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'margin-bottom',
			'units'    => 'px',
		),
	),
	'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Waves_Kirki::add_section( 'layout', array(
	'title'          => __( 'Layout','waves' ),   
	'description'    => __( 'Layout settings that affects overall site', 'waves'),
	'panel'          => 'waves_options', // Not typically needed.
) );



Waves_Kirki::add_field( 'waves', array(
	'settings' => 'primary_sidebar_width',
	'label'    => __( 'Primary Sidebar Width', 'waves' ),
	'section'  => 'layout',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => __( 'One Column', 'waves' ),
		'2' => __( 'Two Column', 'waves' ),
		'3' => __( 'Three Column', 'waves' ),
		'4' => __( 'Four Column', 'waves' ),
		'5' => __( 'Five Column ', 'waves' ),
	),
	'default'  => '5',  
	'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'secondary_sidebar_width',
	'label'    => __( 'Secondary Sidebar Width', 'waves' ),
	'section'  => 'layout',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => __( 'One Column', 'waves' ),
		'2' => __( 'Two Column', 'waves' ),
		'3' => __( 'Three Column', 'waves' ),
		'4' => __( 'Four Column', 'waves' ),
		'5' => __( 'Five Column ', 'waves' ),
	),            
	'default'  => '5',  
	'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','waves'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Waves_Kirki::add_panel( 'footer_panel', array(     
	'title'       => __( 'Footer', 'waves' ),
	'description' => __( 'Footer Related Options', 'waves' ),     
) );  

Waves_Kirki::add_section( 'footer', array(
	'title'          => __( 'Footer','waves' ),
	'description'    => __( 'Footer related options', 'waves'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_widgets',
	'label'    => __( 'Footer Widget Area', 'waves' ),
	'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','waves'),admin_url('customize.php') ),
	'section'  => 'footer',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );
/* Choose No.Of Footer area */
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_widgets_count',
	'label'    => __( 'Choose No.of widget area you want in footer', 'waves' ),
	'section'  => 'footer',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( '1', 'waves' ),
		2  => esc_attr__( '2', 'waves' ),
		3  => esc_attr__( '3', 'waves' ),
		4  => esc_attr__( '4', 'waves' ),
	),
	'default'  => 4,
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'copyright',
	'label'    => __( 'Footer Copyright Text', 'waves' ),
	'section'  => 'footer',
	'type'     => 'textarea',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_top_margin',
	'label'    => __( 'Footer Top Margin', 'waves' ),
	'description' => __('Select the top margin of footer in pixels','waves'),
	'section'  => 'footer',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.site-footer',
			'property' => 'margin-top',
			'units' => 'px',
		),
	),
	'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Waves_Kirki::add_section( 'footer_image', array(
	'title'          => __( 'Footer Image','waves' ),
	'description'    => __( 'Custom Footer Image options', 'waves'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_image',
	'label'    => __( 'Upload Footer Background Image', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-image',
		),
	),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_size',
	'label'    => __( 'Footer Background Size', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'radio-buttonset',
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'waves' ),
		'contain' => esc_attr__( 'Contain', 'waves' ),
		'auto'  => esc_attr__( 'Auto', 'waves' ),
		'inherit'  => esc_attr__( 'Inherit', 'waves' ),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Footer Background Image Size','waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_repeat',
	'label'    => __( 'Footer Background Repeat', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'waves'),
        'repeat' => esc_attr__('Repeat', 'waves'),
        'repeat-x' => esc_attr__('Repeat Horizontally','waves'),
        'repeat-y' => esc_attr__('Repeat Vertically','waves'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_position',
	'label'    => __( 'Footer Background Position', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'waves'),
        'center center' => esc_attr__('Center Center', 'waves'),
        'center bottom' => esc_attr__('Center Bottom', 'waves'),
        'left top' => esc_attr__('Left Top', 'waves'),
        'left center' => esc_attr__('Left Center', 'waves'),
        'left bottom' => esc_attr__('Left Bottom', 'waves'),
        'right top' => esc_attr__('Right Top', 'waves'),
        'right center' => esc_attr__('Right Center', 'waves'),
        'right bottom' => esc_attr__('Right Bottom', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'center center',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_bg_attachment',
	'label'    => __( 'Footer Background Attachment', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'waves'),
        'fixed' => esc_attr__('Fixed', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'scroll',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_overlay',
	'label'    => __( 'Enable Footer( Background ) Overlay', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' )
	),
	'default'  => 'off',
) );
  
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'footer_overlay_color',
	'label'    => __( 'Footer Overlay ( Background )color', 'waves' ),
	'section'  => 'footer_image',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#E5493A', 
	'active_callback' => array(
		array(
			'setting'  => 'footer_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output'   => array(
		array(
			'element'  => '.overlay-footer',
			'property' => 'background-color',
		),
	),
) );
//  social network panel //

Waves_Kirki::add_panel( 'social_panel', array(
	'title'        =>__( 'Social Networks', 'waves'),
	'description'  =>__( 'social networks', 'waves'),
	'priority'  =>11,	
));

//social sharing box section

Waves_Kirki::add_section( 'social_sharing_box', array(
	'title'          =>__( 'Social Sharing Box', 'waves'),
	'description'   =>__('Social Sharing box related options', 'waves'),
	'panel'			 =>'social_panel',
));

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'facebook_sb',
	'label'    => __( 'Enable facebook sharing option below single post', 'waves' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'twitter_sb',
	'label'    => __( 'Enable twitter sharing option below single post', 'waves' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'linkedin_sb',
	'label'    => __( 'Enable linkedin sharing option below single post', 'waves' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'google-plus_sb',
	'label'    => __( 'Enable googleplus sharing option below single post', 'waves' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'email_sb',
	'label'    => __( 'Enable email sharing option below single post', 'waves' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'on',
) );
//  slider panel //

Waves_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'waves' ),  
	'description' => __( 'Flex slider related options', 'waves' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Waves_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','waves' ),
	'description'    => __( 'Flexcaption Related Options', 'waves'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves', array(    
	'settings' => 'enable_flex_caption_edit',
	'label'    => __( 'Enable Custom Flexcaption Settings', 'waves' ),
	'section'  => 'flex_caption_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'waves' ),
		'off' => esc_attr__( 'Disable', 'waves' ) 
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array( 
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'waves' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => 'rgba(51, 51, 51, 0.4)',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'waves' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'left',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'waves' ),
		'right' => esc_attr__( 'Right', 'waves' ),
		'center' => esc_attr__( 'Center', 'waves' ),
		'justify' => esc_attr__( 'Justify', 'waves' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
 Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'waves' ),
	'tooltip' => __('Select how far from right, Default value Left = 10 ( in % )','waves'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '10',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'left',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
 Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'waves' ),
	'tooltip' => __('Select how far from bottom, Default value Top = 10 ( in % )','waves'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '10',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'waves' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '55',
	'tooltip' => __('Select Flexcaption Background Width , Default width value 55','waves'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'waves' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','waves'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'waves' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '#ffffff',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption p,.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption p a,.flexslider .slides .flex-caption p a,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

 if( class_exists( 'WooCommerce' ) ) {
	Waves_Kirki::add_section( 'woocommerce_section', array(
		'title'          => __( 'WooCommerce','waves' ),
		'description'    => __( 'Theme options related to woocommerce', 'waves'),
		'priority'       => 11, 

		'theme_supports' => '', // Rarely needed.
	) );
	Waves_Kirki::add_field( 'woocommerce', array(
		'settings' => 'woocommerce_sidebar',
		'label'    => __( 'Enable Woocommerce Sidebar', 'waves' ),
		'description' => __('Enable Sidebar for shop page','waves'),
		'section'  => 'woocommerce_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'waves' ),
			'off' => esc_attr__( 'Disable', 'waves' ) 
		),

		'default'  => 'on',
	) );
}
	
// background color ( rename )

Waves_Kirki::add_section( 'colors', array(
	'title'          => __( 'Background Color','waves' ),
	'description'    => __( 'This will affect overall site background color', 'waves'),
	//'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 11,
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'general_background_color',
	'label'    => __( 'General Background Color', 'waves' ),
	'section'  => 'colors',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#ffffff',
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-color',
		),
	),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'content_background_color',
	'label'    => __( 'Content Background Color', 'waves' ),
	'section'  => 'colors',
	'type'     => 'color',
	'description' => __('when you are select boxed layout content background color will reflect the grid area','waves'), 
	'alpha' => true, 
	'default'  => '#ffffff',
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'general_background_image',
	'label'    => __( 'General Background Image', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-image',
		),
	),
) );

// background image ( general & boxed layout ) //


Waves_Kirki::add_field( 'waves', array(
	'settings' => 'general_background_repeat',
	'label'    => __( 'General Background Repeat', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'waves'),
        'repeat' => esc_attr__('Repeat', 'waves'),
        'repeat-x' => esc_attr__('Repeat Horizontally','waves'),
        'repeat-y' => esc_attr__('Repeat Vertically','waves'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'general_background_size',
	'label'    => __( 'General Background Size', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'waves' ),
		'contain' => esc_attr__( 'Contain', 'waves' ),
		'auto'  => esc_attr__( 'Auto', 'waves' ),
		'inherit'  => esc_attr__( 'Inherit', 'waves' ),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'cover',  
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'general_background_attachment',
	'label'    => __( 'General Background Attachment', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'waves'),
        'fixed' => esc_attr__('Fixed', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'fixed',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'general_background_position',
	'label'    => __( 'General Background Position', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'waves'),
        'center center' => esc_attr__('Center Center', 'waves'),
        'center bottom' => esc_attr__('Center Bottom', 'waves'),
        'left top' => esc_attr__('Left Top', 'waves'),
        'left center' => esc_attr__('Left Center', 'waves'),
        'left bottom' => esc_attr__('Left Bottom', 'waves'),
        'right top' => esc_attr__('Right Top', 'waves'),
        'right center' => esc_attr__('Right Center', 'waves'),
        'right bottom' => esc_attr__('Right Bottom', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Waves_Kirki::add_field( 'waves', array(  
	'settings' => 'content_background_image',
	'label'    => __( 'Content Background Image', 'waves' ),
	'description' => __('when you are select boxed layout content background image will reflect the grid area','waves'),
	'section'  => 'background_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-image',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'content_background_repeat',
	'label'    => __( 'Content Background Repeat', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'waves'),
        'repeat' => esc_attr__('Repeat', 'waves'),
        'repeat-x' => esc_attr__('Repeat Horizontally','waves'),
        'repeat-y' => esc_attr__('Repeat Vertically','waves'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-repeat',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'content_background_size',
	'label'    => __( 'Content Background Size', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'waves' ),
		'contain' => esc_attr__( 'Contain', 'waves' ),
		'auto'  => esc_attr__( 'Auto', 'waves' ),
		'inherit'  => esc_attr__( 'Inherit', 'waves' ),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-size',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'cover',  
) );

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'content_background_attachment',
	'label'    => __( 'Content Background Attachment', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'waves'),
        'fixed' => esc_attr__('Fixed', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-attachment',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'fixed',  
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'content_background_position',
	'label'    => __( 'Content Background Position', 'waves' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'waves'),
        'center center' => esc_attr__('Center Center', 'waves'),
        'center bottom' => esc_attr__('Center Bottom', 'waves'),
        'left top' => esc_attr__('Left Top', 'waves'),
        'left center' => esc_attr__('Left Center', 'waves'),
        'left bottom' => esc_attr__('Left Bottom', 'waves'),
        'right top' => esc_attr__('Right Top', 'waves'),
        'right center' => esc_attr__('Right Center', 'waves'),
        'right bottom' => esc_attr__('Right Bottom', 'waves'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-position',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'center top',  
) );

do_action('wbls-waves_pro_customizer_options');
do_action('waves_child_customizer_options');
