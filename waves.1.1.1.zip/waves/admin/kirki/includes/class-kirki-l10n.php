<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'waves';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'waves' ),
				'background-image'      => esc_attr__( 'Background Image', 'waves' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'waves' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'waves' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'waves' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'waves' ),
				'inherit'               => esc_attr__( 'Inherit', 'waves' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'waves' ),
				'cover'                 => esc_attr__( 'Cover', 'waves' ),
				'contain'               => esc_attr__( 'Contain', 'waves' ),
				'background-size'       => esc_attr__( 'Background Size', 'waves' ),
				'fixed'                 => esc_attr__( 'Fixed', 'waves' ),
				'scroll'                => esc_attr__( 'Scroll', 'waves' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'waves' ),
				'left-top'              => esc_attr__( 'Left Top', 'waves' ),
				'left-center'           => esc_attr__( 'Left Center', 'waves' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'waves' ),
				'right-top'             => esc_attr__( 'Right Top', 'waves' ),
				'right-center'          => esc_attr__( 'Right Center', 'waves' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'waves' ),
				'center-top'            => esc_attr__( 'Center Top', 'waves' ),
				'center-center'         => esc_attr__( 'Center Center', 'waves' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'waves' ),
				'background-position'   => esc_attr__( 'Background Position', 'waves' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'waves' ),
				'on'                    => esc_attr__( 'ON', 'waves' ),
				'off'                   => esc_attr__( 'OFF', 'waves' ),
				'all'                   => esc_attr__( 'All', 'waves' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'waves' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'waves' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'waves' ),
				'greek'                 => esc_attr__( 'Greek', 'waves' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'waves' ),
				'khmer'                 => esc_attr__( 'Khmer', 'waves' ),
				'latin'                 => esc_attr__( 'Latin', 'waves' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'waves' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'waves' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'waves' ),
				'arabic'                => esc_attr__( 'Arabic', 'waves' ),
				'bengali'               => esc_attr__( 'Bengali', 'waves' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'waves' ),
				'tamil'                 => esc_attr__( 'Tamil', 'waves' ),
				'telugu'                => esc_attr__( 'Telugu', 'waves' ),
				'thai'                  => esc_attr__( 'Thai', 'waves' ),
				'serif'                 => _x( 'Serif', 'font style', 'waves' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'waves' ),
				'monospace'             => _x( 'Monospace', 'font style', 'waves' ),
				'font-family'           => esc_attr__( 'Font Family', 'waves' ),
				'font-size'             => esc_attr__( 'Font Size', 'waves' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'waves' ),
				'line-height'           => esc_attr__( 'Line Height', 'waves' ),
				'font-style'            => esc_attr__( 'Font Style', 'waves' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'waves' ),
				'top'                   => esc_attr__( 'Top', 'waves' ),
				'bottom'                => esc_attr__( 'Bottom', 'waves' ),
				'left'                  => esc_attr__( 'Left', 'waves' ),
				'right'                 => esc_attr__( 'Right', 'waves' ),
				'center'                => esc_attr__( 'Center', 'waves' ),
				'justify'               => esc_attr__( 'Justify', 'waves' ),
				'color'                 => esc_attr__( 'Color', 'waves' ),
				'add-image'             => esc_attr__( 'Add Image', 'waves' ),
				'change-image'          => esc_attr__( 'Change Image', 'waves' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'waves' ),
				'add-file'              => esc_attr__( 'Add File', 'waves' ),
				'change-file'           => esc_attr__( 'Change File', 'waves' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'waves' ),
				'remove'                => esc_attr__( 'Remove', 'waves' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'waves' ),
				'variant'               => esc_attr__( 'Variant', 'waves' ),
				'subsets'               => esc_attr__( 'Subset', 'waves' ),
				'size'                  => esc_attr__( 'Size', 'waves' ),
				'height'                => esc_attr__( 'Height', 'waves' ),
				'spacing'               => esc_attr__( 'Spacing', 'waves' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'waves' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'waves' ),
				'light'                 => esc_attr__( 'Light 200', 'waves' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'waves' ),
				'book'                  => esc_attr__( 'Book 300', 'waves' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'waves' ),
				'regular'               => esc_attr__( 'Normal 400', 'waves' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'waves' ),
				'medium'                => esc_attr__( 'Medium 500', 'waves' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'waves' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'waves' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'waves' ),
				'bold'                  => esc_attr__( 'Bold 700', 'waves' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'waves' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'waves' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'waves' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'waves' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'waves' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'waves' ),
				'add-new'           	=> esc_attr__( 'Add new', 'waves' ),
				'row'           		=> esc_attr__( 'row', 'waves' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'waves' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'waves' ),
				'back'                  => esc_attr__( 'Back', 'waves' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'waves' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'waves' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'waves' ),
				'none'                  => esc_attr__( 'None', 'waves' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'waves' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'waves' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'waves' ),
				'initial'               => esc_attr__( 'Initial', 'waves' ),
				'select-page'           => esc_attr__( 'Select a Page', 'waves' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'waves' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'waves' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'waves' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'waves' ),
			);

			$config = apply_filters( 'kirki/config', array() );

			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
