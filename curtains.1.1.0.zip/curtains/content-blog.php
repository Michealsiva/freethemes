<?php
/**
 * Template part for displaying posts.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package curtains 
 */
?>
<?php do_action('curtains_blog_layout_class_wrapper_before'); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="entry-content"><?php 
		$featured_image = get_theme_mod( 'featured_image',true );
		if( $featured_image ) : ?>
			<div class="post-thumb blog-thumb"><?php
				if( function_exists( 'curtains_featured_image' ) ) :
					curtains_featured_image();
				endif; ?>
				<span class="date-structure posted-on top-date">				
					<span class="dd"><?php the_time('j'); ?></span>
					<span class="mm"><?php the_time('M'); ?></span>
				 </span>
		    </div><?php 
		endif;    

	   do_action('curtains_before_entry_header'); ?>

		<div class="entry-body"><?php 
		    the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); 
				if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
					<footer class="entry-meta"><?php 
				        if(function_exists('curtains_entry_top_meta') ) {
						    curtains_entry_top_meta(); 
						} ?> 
					</footer><!-- .entry-footer --><?php
			    endif; 

			do_action('curtains_after_entry_header'); 

			/* translators: %s: Name of current post */
			the_content();

			do_action('curtains_before_entry_footer'); 	

			if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
				<footer class="entry-footer">
					<?php if(function_exists('curtains_entry_bottom_meta') ) {
					     curtains_entry_bottom_meta();
					} ?>
				</footer><!-- .entry-footer --><?php 
			endif;

		   do_action('curtains_after_entry_footer'); ?>

		</div>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'curtains' ),
				'after'  => '</div>',
			) );
		?>
         <br class="clear" />
    </div><!-- .entry-content -->
</article><!-- #post-## -->

<?php do_action('curtains_blog_layout_class_wrapper_after'); ?>