<?php
/**
 * The front page template file.
 *
 *
 * @package Curtains
 */
	if( 'posts' == get_option( 'show_on_front' ) ) {
	    include( get_home_template() );
	} else { 
    get_header(); 
	if ( get_theme_mod('page-builder',false ) ) { 
		if( get_theme_mod('flexslider') ) {   
			echo do_shortcode( get_theme_mod('flexslider'));
		} ?>  
		<div id="content" class="site-content">
		    <div class="container"><?php    
		    if( get_theme_mod('home_sidebar',false ) ) { ?>
				<div id="primary" class="content-area eleven columns"><?php 
			}else { ?>
				<div id="primary" class="content-area sixteen columns"><?php
			} ?>
				<main id="main" class="site-main" role="main"><?php
					while ( have_posts() ) : the_post();    
						the_content();
					endwhile; ?>
	            </main><!-- #main -->
	        </div><!-- #primary --><?php	
    } else { 
		 if( get_theme_mod('enable_slider',true) ) {
		    get_template_part('category-slider');
		 } ?>

		<div id="content" class="site-content free-home">
			<div class="container"><?php  
			if( get_theme_mod('home_sidebar',false ) ) { ?>
				<div id="primary" class="content-area eleven columns"><?php
			}else { ?>
			    <div id="primary" class="content-area sixteen columns"><?php
			} ?>	
			<main id="main" class="site-main" role="main"><?php 
				do_action('curtains_service_content_before'); 
			    if(get_theme_mod('enable_service',true) ) { 
					    $service = get_theme_mod('service_count',6 );
					    $service_pages = array();
					    for ( $i = 1 ; $i <= $service ; $i++ ) {
							$service_page = absint(get_theme_mod('service_'.$i));
							if( $service_page ){
		                        $service_pages[] = $service_page;
							}
					    }
						if( $service_pages && !empty( $service_pages ) ) {
							$args = array(
								'post_type' => 'page',
								'post__in' => $service_pages,
								'posts_per_page' => -1 ,
								'orderby' => 'post__in'
							);
							if( isset($args) ) :
								$query = new WP_Query($args);
								if( $query->have_posts()) : ?>
									<div class="services-wrapper row"><?php  
									$count=1; 
									while($query->have_posts()) :
										$query->the_post(); ?>
											<?php if ( $count % 2 == 0 ): ?>
											    <div class="eight service columns <?php echo "even";?>">
											<?php else : ?>
											    <div class="eight service columns <?php echo "odd";?>">
											<?php endif; 
										        if( has_post_thumbnail() ) : ?>
										    		<div class="page-thumb">
										    			<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><?php the_post_thumbnail('curtains_home_page_img'); ?></a>
										    		</div>
										    	<?php endif; ?>
										    	<div class="page-content">
										    		<?php the_content(); ?>  
										    	</div>
										    </div>
										 <?php $count++; 
									endwhile; ?>
									</div><?php 
							    endif;
								$query = null;
								wp_reset_postdata();
							endif;
						}elseif( current_user_can('manage_options') ) { ?>
						    <div class="services-wrapper row">
							    <div class="eight service columns odd">
						    		<div class="page-thumb demo-thumb">
						    			<i class="fa fa-thumb-tack fa-4x"></i>	
						    		</div>
				    				<div class="page-content">
				    					<h2><?php _e('Service Page-1','curtains');?></h2>
									     <p><?php printf( __('You haven\'t created any service page yet. Create Page. Go to <a href="%1$s"target="_blank"> Customizer </a> and click curtains Options => Home => Service Section #1 and select page from  dropdown page list.','curtains'), admin_url('customize.php') ) ;?></p>	
							    	</div>
				   				</div> <!-- .service odd -->
				   				 <div class="eight service columns even">
						    		<div class="page-thumb demo-thumb">
						    			<i class="fa fa-thumb-tack fa-4x"></i>	
						    		</div>
				    				<div class="page-content">
				    					<h2><?php _e('Service Page-2','curtains');?></h2>
									     <p><?php printf( __('You haven\'t created any service page yet. Create Page. Go to <a href="%1$s"target="_blank"> Customizer </a> and click curtains Options => Home => Service Section #2 and select page from  dropdown page list.','curtains'), admin_url('customize.php') ) ;?></p>	
							    	</div>
				   				</div> <!-- .service odd -->
				   				<div class="eight service columns odd">
						    		<div class="page-thumb demo-thumb">
						    			<i class="fa fa-thumb-tack fa-4x"></i>	
						    		</div>
				    				<div class="page-content">
				    					<h2><?php _e('Service Page-3','curtains');?></h2>
									     <p><?php printf( __('You haven\'t created any service page yet. Create Page. Go to <a href="%1$s"target="_blank"> Customizer </a> and click curtains Options => Home => Service Section #3 and select page from  dropdown page list.','curtains'), admin_url('customize.php') ) ;?></p>	
							    	</div>
				   				</div> <!-- .service odd -->
				   				 <div class="eight service columns even">
						    		<div class="page-thumb demo-thumb">
						    			<i class="fa fa-thumb-tack fa-4x"></i>	
						    		</div>
				    				<div class="page-content">
				    					<h2><?php _e('Service Page-4','curtains');?></h2>
									     <p><?php printf( __('You haven\'t created any service page yet. Create Page. Go to <a href="%1$s"target="_blank"> Customizer </a> and click curtains Options => Home => Service Section #4 and select page from  dropdown page list.','curtains'), admin_url('customize.php') ) ;?></p>	
							    	</div>
				   				</div> <!-- .service odd -->
				   				<div class="eight service columns odd">
						    		<div class="page-thumb demo-thumb">
						    			<i class="fa fa-thumb-tack fa-4x"></i>	
						    		</div>
				    				<div class="page-content">
				    					<h2><?php _e('Service Page-5','curtains');?></h2>
									     <p><?php printf( __('You haven\'t created any service page yet. Create Page. Go to <a href="%1$s"target="_blank"> Customizer </a> and click curtains Options => Home => Service Section #5 and select page from  dropdown page list.','curtains'), admin_url('customize.php') ) ;?></p>	
							    	</div>
				   				</div> <!-- .service odd -->
				   				 <div class="eight service columns even">
						    		<div class="page-thumb demo-thumb">
						    			<i class="fa fa-thumb-tack fa-4x"></i>	
						    		</div>
				    				<div class="page-content">
				    					<h2><?php _e('Service Page-6','curtains');?></h2>
									     <p><?php printf( __('You haven\'t created any service page yet. Create Page. Go to <a href="%1$s"target="_blank"> Customizer </a> and click curtains Options => Home => Service Section #6 and select page from  dropdown page list.','curtains'), admin_url('customize.php') ) ;?></p>	
							    	</div>
				   				</div> <!-- .service odd -->
				   			</div><?php 
				   	    }
				}
		    do_action('curtains_service_content_after');

			if( get_theme_mod('enable_recent_post_service',true ) ) {
				curtains_recent_posts(); 
			} 	
		 
			if( get_theme_mod('enable_home_default_content',false ) ) {  ?>
				<div class="container default-home-page"><?php
					while ( have_posts() ) : the_post();       
						the_content();
					endwhile; ?>
		         </div><?php 
			} ?>
				</main><!-- #main -->
			</div><!-- #primary -->

		<?php
	}
if( get_theme_mod('home_sidebar',false ) ) { 
   get_sidebar();
}
  get_footer();
} ?>
