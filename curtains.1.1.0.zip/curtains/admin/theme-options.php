<?php
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */
include_once( get_template_directory() . '/admin/kirki/kirki.php' );     
include_once( get_template_directory() . '/admin/kirki-helpers/class-curtains-kirki.php' );
       
Curtains_Kirki::add_config( 'curtains', array(     
	'capability'    => 'edit_theme_options',                  
	'option_type'   => 'theme_mod',         
) );             
     
// Curtains option start //   

//  site identity section // 

Curtains_Kirki::add_section( 'title_tagline', array(
	'title'          => __( 'Site Identity','curtains' ),
	'description'    => __( 'Site Header Options', 'curtains'),       
	'priority'       => 8,         																																														
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'logo_title',
	'label'    => __( 'Enable Logo as Title', 'curtains' ),
	'section'  => 'title_tagline',
	'type'     => 'switch',
	'priority' => 5,
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',   
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'tagline',
	'label'    => __( 'Show site Tagline', 'curtains' ), 
	'section'  => 'title_tagline',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'on',
) );

// home panel //

Curtains_Kirki::add_panel( 'home_options', array(     
	'title'       => __( 'Home', 'curtains' ),
	'description' => __( 'Home Page Related Options', 'curtains' ),     
) );  

// home page type section

Curtains_Kirki::add_section( 'home_type_section', array(
	'title'          => __( 'General Settings','curtains' ),
	'description'    => __( 'Home Page options', 'curtains'),
	'panel'          => 'home_options', // Not typically needed. 
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_home_default_content',
	'label'    => __( 'Enable Home Page Default Content', 'curtains' ),
	'section'  => 'home_type_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	
	'default'  => 'off',
	'tooltip' => __('Enable home page default content ( home page content )','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'home_sidebar',
	'label'    => __( 'Enable sidebar on the Home page', 'curtains' ),
	'section'  => 'home_type_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	
	'default'  => 'off',
	'tooltip' => __('Disable by default. If you want to display the sidebars in your frontpage, turn this Enable.','curtains'),
) );
 

// Slider section

Curtains_Kirki::add_section( 'slider_section', array(
	'title'          => __( 'Slider Section','curtains' ),
	'description'    => __( 'Home Page Slider Related Options', 'curtains'),
	'panel'          => 'home_options', // Not typically needed. 
) );
Curtains_Kirki::add_field( 'curtains', array(  
	'settings' => 'enable_slider',
	'label'    => __( 'Enable Slider Post ( Section )', 'curtains' ),
	'section'  => 'slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ),
	),
	'default'  => 'on',
	'tooltip' => __('Enable Slider Post in home page','curtains'),
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'slider_cat',
	'label'    => __( 'Slider Posts category', 'curtains' ),
	'section'  => 'slider_section',
	'type'     => 'select',
	'choices' => Kirki_Helper::get_terms( 'category' ),
	'active_callback' => array(
		array(
			'setting'  => 'enable_slider',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'slider_count',
	'label'    => __( 'No. of Sliders', 'curtains' ),
	'section'  => 'slider_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 999,
		'step' => 1,
	),
	'default'  => 2,
	'active_callback' => array(
		array(
			'setting'  => 'enable_slider',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','curtains'),
) );
 
// service section 

Curtains_Kirki::add_section( 'service_section', array(
	'title'          => __( 'Service Section','curtains' ),
	'description'    => __( 'Home Page - Service Related Options', 'curtains'),
	'panel'          => 'home_options', // Not typically needed. 
) );

Curtains_Kirki::add_field( 'curtains', array( 
	'settings' => 'enable_service',
	'label'    => __( 'Enable Service Section', 'curtains' ),
	'section'  => 'service_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	
	'default'  => 'on',
	'tooltip' => __('Enable service section in home page','curtains'),
) ); 
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'service_count',
	'label'    => __( 'No. of Service Section', 'curtains' ),
	'description' => __('Save the Settings, and Reload this page to Configure the service section','curtains'),
	'section'  => 'service_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 2,
		'max' => 99,
		'step' => 1,
	),
	'default'  => 6,
	'active_callback' => array(
		array(
			'setting'  => 'enable_service',
			'operator' => '==',
			'value'    => true,
		),	
    ),
    'tooltip' => __('Enter number of service page you want to display','curtains'),
) );

if ( get_theme_mod('service_count') > 0 ) {
 $service = get_theme_mod('service_count');
 		for ( $i = 1 ; $i <= $service ; $i++ ) {
             //Create the settings Once, and Loop through it.
 			Curtains_Kirki::add_field( 'curtains', array(
				'settings' => 'service_'.$i,
				'label'    => sprintf(__( 'Service Section #%1$s', 'curtains' ), $i ),
				'section'  => 'service_section',
				'type'     => 'dropdown-pages',	
				//'tooltip' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','curtains'),
				'active_callback' => array(
					array(
						'setting'  => 'enable_service',
						'operator' => '==',
						'value'    => true,
					),
					
                ), 
               // 'description' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','curtains'),
        
			) );
 		}
}

// latest blog section 

Curtains_Kirki::add_section( 'latest_blog_section', array(
	'title'          => __( 'Latest Blog Section','curtains' ),
	'description'    => __( 'Home Page - Latest Blog Options', 'curtains'),
	'panel'          => 'home_options', // Not typically needed. 
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_recent_post_service',
	'label'    => __( 'Enable Recent Post Section', 'curtains' ),
	'section'  => 'latest_blog_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable recent post section in home page','curtains'),
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'recent_posts_count',
	'label'    => __( 'No. of Recent Posts', 'curtains' ),
	'section'  => 'latest_blog_section',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 99,
		'step' => 1,
	),
	'default'  => 8,
	'active_callback' => array(
		array(
			'setting'  => 'enable_recent_post_service',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

// general panel   

Curtains_Kirki::add_panel( 'general_panel', array(   
	'title'       => __( 'General Settings', 'curtains' ),  
	'description' => __( 'general settings', 'curtains' ),         
) );

//  Page title bar section // 

Curtains_Kirki::add_section( 'header-pagetitle-bar', array(   
	'title'          => __( 'Page Title Bar','curtains' ),
	'description'    => __( 'Page Title bar related options', 'curtains'),
	'panel'          => 'general_panel', // Not typically needed.
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'page_titlebar',  
	'label'    => __( 'Page Title Bar', 'curtains' ),
	'section'  => 'header-pagetitle-bar', 
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show Bar and Content', 'curtains' ),
		2 => __( 'Show Content Only ', 'curtains' ),
		3 => __('Hide','curtains'),
    ),
    'default' => 1,
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'page_titlebar_text',  
	'label'    => __( 'Page Title Bar Text', 'curtains' ),
	'section'  => 'header-pagetitle-bar', 
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'curtains' ),
		2 => __( 'Hide', 'curtains' ), 
    ),
    'default' => 1,
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'breadcrumb',  
	'label'    => __( 'Breadcrumb', 'curtains' ),
	'section'  => 'header-pagetitle-bar', 
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ),
	),
	'default'  => 'on',
) ); 

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'breadcrumb_char',
	'label'    => __( 'Breadcrumb Character', 'curtains' ),
	'section'  => 'header-pagetitle-bar',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( ' >> ', 'curtains' ),
		2 => __( ' / ', 'curtains' ),
		3 => __( ' > ', 'curtains' ),
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'breadcrumb',
			'operator' => '==',
			'value'    => true,
		),
	),
) );

//  pagination section // 

Curtains_Kirki::add_section( 'general-pagination', array(   
	'title'          => __( 'Pagination','curtains' ),
	'description'    => __( 'Pagination related options', 'curtains'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'numeric_pagination',
	'label'    => __( 'Numeric Pagination', 'curtains' ),   
	'section'  => 'general-pagination',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Numbered', 'curtains' ),
		'off' => esc_attr__( 'Next/Previous', 'curtains' )
	),
	'default'  => 'on',
) );

// skin color panel 

Curtains_Kirki::add_panel( 'skin_color_panel', array(   
	'title'       => __( 'Skin Color', 'curtains' ),  
	'description' => __( 'Color Settings', 'curtains' ),         
) );

// Change Color Options

Curtains_Kirki::add_section( 'primary_color_field', array(
	'title'          => __( 'Change Color Options','curtains' ),
	'description'    => __( 'This will reflect in links, buttons,Navigation and many others. Choose a color to match your site.', 'curtains'),
	'panel'          => 'skin_color_panel', // Not typically needed.
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_primary_color',
	'label'    => __( 'Enable Custom Primary color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#3c5895',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'button:focus,
							input[type="button"]:focus,     
							input[type="reset"]:focus,
							input[type="submit"]:focus,
							button:active,
							input[type="button"]:active,
							input[type="reset"]:active,
							input[type="submit"]:active,.tabs-container div,.widget_image-box-widget .image-box img,.ui-accordion .ui-accordion-content,.circle-icon-box .circle-icon-wrapper .fa-stack i:after,.toggle .toggle-content,.flex-direction-nav a:hover:before,.flex-direction-nav a:hover:after',
			'property' => 'border-color',
		),
		array(
			'element'  => '.slicknav_menu a:hover,.widget_testimonial-widget .flex-control-nav a.flex-active,.widget_testimonial-widget .flex-control-nav a:hover,.nav-links .nav-previous .meta-nav:hover,.more-link .nav-previous .meta-nav:hover,.comment-navigation .nav-previous .meta-nav:hover,
							input[type="button"],.nav-links .nav-next:hover a,.more-link .nav-next:hover a,.comment-navigation .nav-next:hover a,a.more-link:hover,.widget_tag_cloud a,.site-footer .widget_tag_cloud a,
							input[type="reset"],ol.webulous_page_navi li a,.tabs-container ul.tabs,.flex-direction-nav a:hover,.notice,.share-box ul li a:hover,
							input[type="submit"],.btn,.dropcap-circle,.dropcap-book,.pullright,.toggle-normal .toggle-title,.widget_recent-posts-widget .flex-control-nav li a,
							.pullleft,.withtip:before,.withtip.top:after,.withtip.right:after,.withtip.bottom:after,.withtip.left:after,.page-template-blog-fullwidth .site-main .sticky .entry-content,
							.page-template-blog-large .site-main .sticky .entry-content,.blog .site-main .sticky .entry-content,.page-template-blog-small .site-main .sticky .entry-content,
							.pullnone,.circle-icon-box a.more-button:hover,.circle-icon-box:hover .circle-icon-wrapper .fa-stack i:after,
							.dropcap-box,.icon-polygon a.more-button:hover,.wide-pattern-black .widget_testimonial-widget .flex-direction-nav a:hover,
							.widget_button-widget a.btn.btn-default,.flex-direction-nav a.flex-next:hover,.nav-links .nav-previous:hover a,.more-link .nav-previous:hover a,.comment-navigation .nav-previous:hover a,.woocommerce #respond input#submit:hover,
							blockquote,.widget.widget_skill-widget .skill-container .skill .skill-percentage,.ui-accordion h3,
							.entry-meta,blockquote p,.ui-accordion .ui-accordion-header-active,
							.entry-footer,.widget_recent-work-widget .portfolioeffects .overlay_icon a:hover,.widget_recent-work-widget .work .overlay_icon a:hover,
							.portfolioeffects .overlay_icon a:hover,.portfolio-excerpt .more-link,.widget_calendar table caption,.site-footer .widget_calendar caption,
							.flex-direction-nav a.flex-prev:hover,.flex-direction-nav a.flex-next:hover,
							.icon-horizontal a.link-title i,.widget_recent-posts-widget .recent-post:hover a img,
							  .icon-horizontal .icon-title i,.widget_image-box-widget a.more-button,
							  .icon-horizontal .fa-stack i,
							  .icon-vertical a.link-title i,
							  .icon-vertical .icon-title i,.site-content .widget_social-networks-widget ul li a:hover, .site-content .share-box ul li a:hover,
							  .icon-vertical .fa-stack i,.icon-horizontal:hover .more-button a,
							.icon-vertical:hover .more-button a,
							.contact-form input[type="submit"],.widget.widget_skill-widget .skill-container .skill .skill-percentage,.widget.widget_skill-widget .skill-container .skill .skill-percentage:before,
							.woocommerce #content div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce-page div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce #content div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce-page div.product .woocommerce-tabs ul.tabs li.active,.woocommerce #content nav.woocommerce-pagination ul li a:focus,
							.woocommerce #content nav.woocommerce-pagination ul li a:hover,
							.woocommerce #content nav.woocommerce-pagination ul li span.current,
							.woocommerce nav.woocommerce-pagination ul li a:focus,
							.woocommerce nav.woocommerce-pagination ul li a:hover,
							.woocommerce nav.woocommerce-pagination ul li span.current,
							.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
							.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,
							.woocommerce-page #content nav.woocommerce-pagination ul li span.current,
							.woocommerce-page nav.woocommerce-pagination ul li a:focus,
							.woocommerce-page nav.woocommerce-pagination ul li a:hover,
							.woocommerce-page nav.woocommerce-pagination ul li span.current',
			'property' => 'background-color',
		),
		/*array(
			'element'  => '.main-navigation a:hover::after,
							 .main-navigation .current_page_item > a::after,
							 .main-navigation .current-menu-item > a::after,
							 .main-navigation .current_page_ancestor > a::after,
							 .main-navigation .current_page_parent > a::after,.widget_magazine-post-boxed-widget .entry-content .cat-links a::after,.widget_magazine-post-boxed-widget .mag-divider::after ',
			'property' => 'border-left-color',
		),*/
		array(
			'element'  => '.main-navigation .current_page_item,.woocommerce #content table.cart a.remove,.widget_testimonial-widget ul li p.client,
							.widget_recent-work-widget .portfolioeffects .content-details h3 a:hover,.widget_recent-work-widget .work .content-details h3 a:hover,
							.breadcrumb-wrap .breadcrumb a:hover,.breadcrumb-wrap .breadcrumb a:hover i,.site-info a:hover,
							.main-navigation .sub-menu li a:hover,.main-navigation .children li a:hover,.toggle-polygon .toggle-title:hover,.toggle-normal .toggle-title span.icn .fa,.widget-area .widget_rss a,.site-footer .footer-widgets a:hover,.site-footer .footer-widgets .widget_calendar a,.site-footer .footer-widgets .widget_calendar td#today,
							.main-navigation .current-menu-item,.widget_testimonial-widget ul li p.client,.flexslider .flex-caption a:hover,
							.main-navigation .current_page_ancestor,.circle-icon-box .circle-icon-wrapper .link-icon:hover,.main-navigation .current_page_item > a,.order-total .amount,
							.cart-subtotal .amount,.widget.widget_ourteam-widget .team-social li a:hover,.widget.widget_skill-widget .skill-container .fa-stack,
							.main-navigation .current-menu-item > a,ul#portfolio li h3 a:hover,.circle-icon-box:hover a.link-title,.circle-icon-box:hover a.link-title h4,.circle-icon-box:hover .link-title h4,.circle-icon-box:hover a.more-button,
							.main-navigation .current_page_ancestor > a,.main-navigation .sub-menu .current_page_item,.recent-post .rp-content h4 a:hover,
							.main-navigation .sub-menu .current-menu-item,ul.filter-options li a:hover,.icon-polygon:hover .circle-icon-wrapper .fa,.icon-polygon:hover .link-icon i,.icon-polygon:hover .link-title h4,.callout-widget .cta-link a:hover,
							.main-navigation .sub-menu .current_page_ancestor,.ui-accordion h3 span.fa,.recent-post .rp-content h4:hover,
							.main-navigation .children .current_page_item,.widget_recent-work-widget ul.filter-options li a:hover,.portfolioeffects .content-details h3 a:hover,
							.main-navigation .children-menu .current-menu-item,.free-home .post-wrapper .latest-posts .latest-post-thumb:hover h4,.widget-area ul li a:hover,#secondary #recentcomments a,.widget_calendar table th a,.widget_calendar table td a,
							.main-navigation .children-menu .current_page_ancestor,.main-navigation .sub-menu .current_page_item > a,
							.main-navigation .sub-menu .current-menu-item > a,.free-home .services-wrapper .service:hover h6,.free-home .services-wrapper .service:hover h5,.free-home .services-wrapper .service:hover h4,.free-home .services-wrapper .service:hover h3,.free-home .services-wrapper .service:hover h2,.free-home .services-wrapper .service:hover h1,
							.main-navigation .sub-menu .current_page_ancestor > a,.page-links a,.page-template-blog-fullwidth .site-main .entry-body h1 a:hover,
							.page-template-blog-large .site-main .entry-body h1 a:hover,.blog .site-main .entry-body h1 a:hover,.page-template-blog-small .site-main .entry-body h1 a:hover,
							.main-navigation .children .current_page_item > a,.widget_list-widget ul li .fa,.widget_list-widget ol li .fa,ol.comment-list article,.comment-metadata a:hover,.hentry.post h1 a:hover,.entry-title a:hover,.site-info a:hover,.copyright p a,
							.main-navigation .children .current-menu-item > a,.site-header .branding .site-branding .site-title a:hover,.top-nav ul li:hover a,ol.comment-list .reply:before,
							.main-navigation .children .current_page_ancestor > a,.post-wrapper .latest-posts .latest-post-thumb:hover h4,.site-header .branding .site-branding h1.site-title a:hover,.site-footer .widget_recent-posts-widget .recent-post .rp-content h4 a:hover,.main-navigation .sub-menu li a:hover, .main-navigation .children li a:hover,.main-navigation .sub-menu li a:hover,.main-navigation .children li a:hover,.main-navigation ul.nav-menu > li a:hover,.main-navigation .sub-menu li a:hover,.main-navigation .children li a:hover,
							.order-total .amount,
							.cart-subtotal .amount,.woocommerce #content table.cart a.remove,
							.woocommerce table.cart a.remove,
							.woocommerce-page #content table.cart a.remove,
							.woocommerce-page table.cart a.remove',
			'property' => 'color',
		),
		/*array(
			'element'  => 'th a,
							.left-sidebar #recentcomments a,
							#recentcomments a,
							.left-sidebar .widget_rss a,
							.widget_tag_cloud a:hover,.widget_magazine-featured-slider-widget .magazine-featured-slider-wrapper .flexslider .slides .flex-caption a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element'  => '.woocommerce #content input.button:hover,
							.woocommerce #respond input#submit:hover,
							.woocommerce a.button:hover,
							.woocommerce button.button:hover,
							.woocommerce input.button:hover,
							.woocommerce-page #content input.button:hover,
							.woocommerce-page #respond input#submit:hover,
							.woocommerce-page a.button:hover,
							.woocommerce-page button.button:hover,
							.woocommerce-page input.button:hover',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => 'li.ui-tabs-active:before,.sep:after,
							.tabs-container.center div,.widget.widget_ourteam-widget .team-social li a:hover',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.toggle-polygon .toggle-title',
			'property' => 'border-bottom-color',
		),
		array(
			'element' => '.faq-acc .ui-accordion-header-active:after,
							.toggle-normal .toggle-title,.tabs-container ul.tabs,
							.ui-accordion .ui-accordion-header-active ',
			'property' => 'border-right-color',
		),
		array(
			'element' => '.faq-acc .ui-accordion-header-active:before,
						  .toggle-normal .toggle-title,.tabs-container div:before,
						  .ui-accordion .ui-accordion-header-active',
			'property' => 'border-left-color',
		),
	),
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_nav_bar_color',
	'label'    => __( 'Enable Navigation Bar BG Color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'nav_bar_color',
	'label'    => __( 'Navigation Bar BG Color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_nav_bar_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.site-header .branding .site-branding,.main-navigation',
			'property' => 'background-color',
		),
	),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_nav_dd_bg_color',
	'label'    => __( 'Enable Navigation Dropdown BG Color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'nav_dd_bg_color',
	'label'    => __( 'Navigation Dropdown BG Color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_nav_dd_bg_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.main-navigation .sub-menu, .main-navigation .children',
			'property' => 'background-color',
		),
	),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_nav_dd_bg_hover_color',
	'label'    => __( 'Enable Navigation Dropdown Hover color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',
) );    
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'nav_dd_bg_hover_color',
	'label'    => __( 'Navigation Dropdown Hover color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_nav_dd_bg_hover_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.main-navigation .sub-menu li a:hover, .main-navigation .children li a:hover',
			'property' => 'background-color',
		),
	),
) );
/*Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_secondary_color',
	'label'    => __( 'Enable Custom Secondary color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'curtains' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#222222',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.not-found-inner a:hover,
							.footer-bottom p a:hover,
							.entry-meta span a:hover,
							.entry-footer span a:hover,
							#secondary .widget_rss .widget-title .rsswidget,
							.footer-top ul li a,
							.more-link .meta-nav,
							.error-404.not-found,
							a.more-link,
							.site-main .comment-navigation a:hover,
							a:hover,
							a:focus,
							a:active,
							.comment-list > li article .reply:hover i,
							.comment-list > li article .comment-meta .comment-author b:hover,
							.comment-list > li article .comment-meta .comment-author a:hover,
							.comment-list > li article .comment-meta .comment-author cite:hover,
							.widget_calendar table th a:hover,
							.widget_calendar table td a:hover',
			'property' => 'color',
		),
		array(
			'element' => 'th a:hover,
							#recentcomments a:hover,
							.left-sidebar .widget_rss a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element' => '.home .flexslider .slides .flex-caption p a:hover,
							.home .flexslider .slides .flex-caption a:hover,
							.footer-widgets .textwidget .wpcf7-form input.wpcf7-submit:hover,
							.site-header .branding .social .widget .textwidget li a,
							.share-box ul li a,
							.site-footer .widget_social-networks-widget ul li a:hover,
							.site-footer .search-form input.search-submit:hover,
							.site-footer .search-form input[type="submit"]:hover',
			'property' => 'background-color',
		),
       array(
			'element' => '.flexslider .slides .flex-caption p a::after',
			'property' => 'border-left-color',
			'suffix' => '!important',
		),
        array(
			'element' => '.social .widget_social-networks-widget ul li a::after',
			'property' => 'border-top-color',
		),
	),
) );*/
// typography panel //

Curtains_Kirki::add_panel( 'typography', array( 
	'title'       => __( 'Typography', 'curtains' ),
	'description' => __( 'Typography and Link Color Settings', 'curtains' ),
) );
   
    Curtains_Kirki::add_section( 'typography_section', array(
		'title'          => __( 'General Settings','curtains' ),
		'description'    => __( 'General Settings', 'curtains'),
		'panel'          => 'typography', // Not typically needed.
	) );
	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'custom_typography',
		'label'    => __( 'Enable Custom Typography', 'curtains' ),
		'description' => __('Save the Settings, and Reload this page to Configure the typography section','curtains'),
		'section'  => 'typography_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'curtains' ),
			'off' => esc_attr__( 'Disable', 'curtains' )
		),
		'tooltip' => __('Turn on to customize typography and turn off for default typography','curtains'),
		'default'  => 'off',
	) );

$typography_setting = get_theme_mod('custom_typography',false );
if( $typography_setting ) :

        $body_font = get_theme_mod('body_family','Ubuntu');		        
	    $body_color = get_theme_mod( 'body_color','#282827' );
		$body_size = get_theme_mod( 'body_size','16');
		$body_weight = get_theme_mod( 'body_weight','regular');
		$body_weight == 'bold' ? $body_weight = '400':  $body_weight = 'regular';
		

	Curtains_Kirki::add_section( 'body_font', array(
		'title'          => __( 'Body Font','curtains' ),
		'description'    => __( 'Specify the body font properties', 'curtains'),
		'panel'          => 'typography', // Not typically needed.
	) ); 


	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'body',
		'label'    => __( 'Body Settings', 'curtains' ),
		'section'  => 'body_font', 
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $body_font,
			'variant'        => $body_weight,
			'font-size'      => $body_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $body_color,
		),
		'output'      => array(
			array(
				'element' => 'body',
				//'suffix' => '!important',
			),
		),
	) );


	Curtains_Kirki::add_section( 'heading_section', array(
		'title'          => __( 'Heading Font','curtains' ),
		'description'    => __( 'Specify typography of h1,h2,h3,h4,h5,h6', 'curtains'),
		'panel'          => 'typography', // Not typically needed.
	) );

	$h1_font = get_theme_mod('h1_family','Arvo');
	$h1_color = get_theme_mod( 'h1_color','#282827' );
	$h1_size = get_theme_mod( 'h1_size','48');
	$h1_weight = get_theme_mod( 'h1_weight','700');
	$h1_weight == 'bold' ? $h1_weight = '700' : $h1_weight = 'regular';

	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'h1',
		'label'    => __( 'H1 Settings', 'curtains' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h1_font,
			'variant'        => $h1_weight,
			'font-size'      => $h1_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h1_color,
		),
		'output'      => array(
			array(
				'element' => 'h1',
			),
		),
		
	) );

	$h2_font = get_theme_mod('h2_family','Arvo');
	$h2_color = get_theme_mod( 'h2_color','#282827' );
	$h2_size = get_theme_mod( 'h2_size','36');
	$h2_weight = get_theme_mod( 'h2_weight','700');
	$h2_weight == 'bold' ? $h2_weight = '700' : $h2_weight = 'regular';

	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'h2',
		'label'    => __( 'H2 Settings', 'curtains' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h2_font,
			'variant'        => $h2_weight,
			'font-size'      => $h2_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h2_color,
		),
		'output'      => array(
			array(
				'element' => 'h2',
			),
		),
		
	) );

	$h3_font = get_theme_mod('h3_family','Arvo');
	$h3_color = get_theme_mod( 'h3_color','#282827' );
	$h3_size = get_theme_mod( 'h3_size','30');
	$h3_weight = get_theme_mod( 'h3_weight','700');
	$h3_weight == 'bold' ? $h3_weight = '700' : $h3_weight = 'regular';

	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'h3',
		'label'    => __( 'H3 Settings', 'curtains' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default' => array(
			'font-family'    => $h3_font,
			'variant'        => $h3_weight,
			'font-size'      => $h3_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h3_color,
		),
		'output'      => array(
			array(
				'element' => 'h3',
			),
		),
		
	) );

	$h4_font = get_theme_mod('h4_family','Arvo');
	$h4_color = get_theme_mod( 'h4_color','#282827' );
	$h4_size = get_theme_mod( 'h4_size','24');
	$h4_weight = get_theme_mod( 'h4_weight','700');
	$h4_weight == 'bold' ? $h4_weight = '700' : $h4_weight = 'regular';


	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'h4',
		'label'    => __( 'H4 Settings', 'curtains' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h4_font,
			'variant'        => $h4_weight,
			'font-size'      => $h4_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h4_color,
		),
		'output'      => array(
			array(
				'element' => 'h4',
			),
		),
		
	) );

    $h5_font = get_theme_mod('h5_family','Arvo');
	$h5_color = get_theme_mod( 'h5_color','#282827' );
	$h5_size = get_theme_mod( 'h5_size','18');
	$h5_weight = get_theme_mod( 'h5_weight','700');
	$h5_weight == 'bold' ? $h5_weight = '700' : $h5_weight = 'regular';


	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'h5',
		'label'    => __( 'H5 Settings', 'curtains' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h5_font,
			'variant'        => $h5_weight,
			'font-size'      => $h5_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h5_color,
		),
		'output'      => array(
			array(
				'element' => 'h5',
			),
		),
		
	) );

	$h6_font = get_theme_mod('h6_family','Arvo');
	$h6_color = get_theme_mod( 'h6_color','#282827' );
	$h6_size = get_theme_mod( 'h6_size','16');
	$h6_weight = get_theme_mod( 'h6_weight','700');
	$h6_weight == 'bold' ? $h6_weight = '700' : $h6_weight = 'regular';


	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'h6',
		'label'    => __( 'H6 Settings', 'curtains' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h6_font,
			'variant'        => $h6_weight,
			'font-size'      => $h6_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h6_color,
		),
		'output'      => array(
			array(
				'element' => 'h6',
			),
		),
		
	) );

	// navigation font 
	Curtains_Kirki::add_section( 'navigation_section', array(
		'title'          => __( 'Navigation Font','curtains' ),
		'description'    => __( 'Specify Navigation font properties', 'curtains'),
		'panel'          => 'typography', // Not typically needed.
	) );

	Curtains_Kirki::add_field( 'curtains', array(
		'settings' => 'navigation_font',
		'label'    => __( 'Navigation Font Settings', 'curtains' ),
		'section'  => 'navigation_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => 'Ubuntu',
			'variant'        => '700',
			'font-size'      => '15px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => '#000',
		),
		'output'      => array(
			array(
				'element' => '.main-navigation a',
			),
		),
	) );
endif; 


// header panel //

Curtains_Kirki::add_panel( 'header_panel', array(     
	'title'       => __( 'Header', 'curtains' ),
	'description' => __( 'Header Related Options', 'curtains' ), 
) );  

/*Curtains_Kirki::add_section( 'header', array(
	'title'          => __( 'General Header','curtains' ),
	'description'    => __( 'Header options', 'curtains'),
	'panel'          => 'header_panel', // Not typically needed.  
) );    

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_text_color',
	'label'    => __( 'Header Text Color', 'curtains' ),
	'section'  => 'header',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#000', 
	'output'   => array(
		array(
			'element'  => '.main-navigation a,
							.main-navigation ul ul a',
			'property' => 'color',
		),
	),
) );*/
/*Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_search',
	'label'    => __( 'Enable to Show Search box in Header', 'curtains' ), 
	'section'  => 'header',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'on',
) );*/
/* Breaking News section  */
/*Curtains_Kirki::add_section( 'header_breaking_news', array(
	'title'          => __( 'Breaking News','curtains' ),
	'description'    => __( 'Breaking News', 'curtains'),
	'panel'          => 'header_panel', // Not typically needed.
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_breaking_news',
	'label'    => __( 'Enable Breaking News', 'curtains' ), 
	'section'  => 'header_breaking_news',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	
	'default'  => 'off',
) );*/
/* STICKY HEADER section */   

Curtains_Kirki::add_section( 'stricky_header', array(
	'title'          => __( 'Sticky Menu','curtains' ),
	'description'    => __( 'sticky header', 'curtains'),
	'panel'          => 'header_panel', // Not typically needed.
) );
Curtains_Kirki::add_field( 'curtains', array(    
	'settings' => 'sticky_header',
	'label'    => __( 'Enable Sticky Header', 'curtains' ),
	'section'  => 'stricky_header',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'on',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'sticky_header_position',
	'label'    => __( 'Enable Sticky Header Position', 'curtains' ),
	'section'  => 'stricky_header',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'top'  => esc_attr__( 'Top', 'curtains' ),
		'bottom' => esc_attr__( 'Bottom', 'curtains' )
	),
	'active_callback'    => array(
		array(
			'setting'  => 'sticky_header',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'top',
) );
/*
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_top_margin',
	'label'    => __( 'Header Top Margin', 'curtains' ),
	'description' => __('Select the top margin of header in pixels','curtains'),
	'section'  => 'header',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1,
	),
	//'default'  => '213',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_bottom_margin',
	'label'    => __( 'Header Bottom Margin', 'curtains' ),
	'description' => __('Select the bottom margin of header in pixels','curtains'),
	'section'  => 'header',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1,
	),
	//'default'  => '213',
) );*/

Curtains_Kirki::add_section( 'header_image', array(
	'title'          => __( 'Header Background Image & Video','curtains' ),
	'description'    => __( 'Custom Header Image & Video options', 'curtains'),
	'panel'          => 'header_panel', // Not typically needed.  
) );

Curtains_Kirki::add_field( 'curtains', array(   
	'settings' => 'header_bg_size',
	'label'    => __( 'Header Background Size', 'curtains' ),
	'section'  => 'header_image',
	'type'     => 'radio-buttonset', 
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'curtains' ),
		'contain' => esc_attr__( 'Contain', 'curtains' ),
		'auto'  => esc_attr__( 'Auto', 'curtains' ),
		'inherit'  => esc_attr__( 'Inherit', 'curtains' ),
	),
	'output'   => array(
		array(
			'element'  => '.header-image',
			'property' => 'background-size',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Header Background Image Size','curtains'),
) );

/*Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_height',
	'label'    => __( 'Header Background Image Height', 'curtains' ),
	'section'  => 'header_image',
	'type'     => 'number',
	'choices' => array(
		'min' => 100,
		'max' => 600,
		'step' => 1,
	),
	'default'  => '213',
) ); */
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_bg_repeat',
	'label'    => __( 'Header Background Repeat', 'curtains' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'curtains'),
        'repeat' => esc_attr__('Repeat', 'curtains'),
        'repeat-x' => esc_attr__('Repeat Horizontally','curtains'),
        'repeat-y' => esc_attr__('Repeat Vertically','curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.header-image',
			'property' => 'background-repeat',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'repeat',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_bg_position', 
	'label'    => __( 'Header Background Position', 'curtains' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'curtains'),
        'center center' => esc_attr__('Center Center', 'curtains'),
        'center bottom' => esc_attr__('Center Bottom', 'curtains'),
        'left top' => esc_attr__('Left Top', 'curtains'),
        'left center' => esc_attr__('Left Center', 'curtains'),
        'left bottom' => esc_attr__('Left Bottom', 'curtains'),
        'right top' => esc_attr__('Right Top', 'curtains'),
        'right center' => esc_attr__('Right Center', 'curtains'),
        'right bottom' => esc_attr__('Right Bottom', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.header-image',
			'property' => 'background-position',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'center center',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_bg_attachment',
	'label'    => __( 'Header Background Attachment', 'curtains' ),
	'section'  => 'header_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'curtains'),
        'fixed' => esc_attr__('Fixed', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.header-image',
			'property' => 'background-attachment',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_image',
			'operator' => '!=',
			'value'    => 'remove-header',
		),
	),
	'default'  => 'scroll',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_overlay',
	'label'    => __( 'Enable Header( Background ) Overlay', 'curtains' ),
	'section'  => 'header_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',
) );
  
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'header_overlay_color',
	'label'    => __( 'Header Overlay ( Background )color', 'curtains' ),
	'section'  => 'header_image',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#3c5895', 
	'output'   => array(
		array(
			'element'  => '.overlay-header',
			'property' => 'background-color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'header_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
) );

/*
/* e-option start */
/*
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'custon_favicon',
	'label'    => __( 'Custom Favicon', 'curtains' ),
	'section'  => 'header',
	'type'     => 'upload',
	'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Curtains_Kirki::add_panel( 'blog_panel', array(     
	'title'       => __( 'Blog', 'curtains' ),
	'description' => __( 'Blog Related Options', 'curtains' ),     
) ); 
Curtains_Kirki::add_section( 'blog', array(
	'title'          => __( 'Blog Page','curtains' ),
	'description'    => __( 'Blog Related Options', 'curtains'),
	'panel'          => 'blog_panel', // Not typically needed.
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'blog-slider',
	'label'    => __( 'Enable to show the slider on blog page', 'curtains' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'off',
	'tooltip' => __('To show the slider on posts page','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'blog_layout',
	'label'    => __( 'Select Blog Page Layout you prefer', 'curtains' ),
	'section'  => 'blog',
	'type'     => 'select',
	'multiple'  => 1,
	'choices' => array(
		1  => esc_attr__( 'Default ( One Column )', 'curtains' ),
		2 => esc_attr__( 'Two Columns ', 'curtains' ),
		3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'curtains' ),
		4 => esc_attr__( 'Two Columns With Masonry', 'curtains' ),
		5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'curtains' ),
	),
	'default'  => 1,
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'featured_image',
	'label'    => __( 'Enable Featured Image', 'curtains' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable Featured Image for blog page','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'more_text',
	'label'    => __( 'More Text', 'curtains' ),
	'section'  => 'blog',
	'type'     => 'text',
	'description' => __('Text to display in case of text too long','curtains'),
	'default' => __('Read More','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'featured_image_size',
	'label'    => __( 'Choose the Featured Image Size for Blog Page', 'curtains' ),
	'section'  => 'blog',
	'type'     => 'select',
	'multiple'  => 1,
	'choices' => array(
		1 => esc_attr__( 'Large Featured Image', 'curtains' ),
		2 => esc_attr__( 'Small Featured Image', 'curtains' ),
		3 => esc_attr__( 'Original Size', 'curtains' ),
		4 => esc_attr__( 'Medium', 'curtains' ),
		5 => esc_attr__( 'Large', 'curtains' ), 
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'curtains') ,
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_single_post_top_meta',
	'label'    => __( 'Enable to display top post meta data', 'curtains' ),
	'section'  => 'blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'single_post_top_meta',
	'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'curtains' ),
	'section'  => 'blog',
	'type'     => 'sortable',
	'choices'     => array(
		1 => esc_attr__( 'date', 'curtains' ),
		2 => esc_attr__( 'author', 'curtains' ),
		3 => esc_attr__( 'comment', 'curtains' ),
		4 => esc_attr__( 'category', 'curtains' ),
		5 => esc_attr__( 'tags', 'curtains' ),
		6 => esc_attr__( 'edit', 'curtains' ),
	),
	'default'  => array(2,3,6),
	'active_callback' => array(
		array(
			'setting'  => 'enable_single_post_top_meta',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','curtains'),

) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'enable_single_post_bottom_meta',
	'label'    => __( 'Enable to display bottom post meta data', 'curtains' ),
	'section'  => 'blog', 
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','curtains'),
	'default'  => 'on',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'single_post_bottom_meta',
	'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'curtains' ),
	'section'  => 'blog',
	'type'     => 'sortable',
	'choices'     => array(
		1 => esc_attr__( 'date', 'curtains' ),
		2 => esc_attr__( 'author', 'curtains' ),
		3 => esc_attr__( 'comment', 'curtains' ),
		4 => esc_attr__( 'category', 'curtains' ),
		5 => esc_attr__( 'tags', 'curtains' ),
		6 => esc_attr__( 'edit', 'curtains' ),
	),
	'default'  => array(4,5),
	'active_callback' => array(
		array(
			'setting'  => 'enable_single_post_bottom_meta',
			'operator' => '==',
			'value'    => true,
		),  
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','curtains'),
) );


/* Single Blog page section */

Curtains_Kirki::add_section( 'single_blog', array(
	'title'          => __( 'Single Blog Page','curtains' ),
	'description'    => __( 'Single Blog Page Related Options', 'curtains'),
	'panel'          => 'blog_panel', // Not typically needed.
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'single_featured_image',
	'label'    => __( 'Enable Single Post Featured Image', 'curtains' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Enable Featured Image for Single Post Page','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'single_featured_image_size',
	'label'    => __( 'Choose the featured image display type for Single Post Page', 'curtains' ),
	'section'  => 'single_blog',
	'type'     => 'radio',
	'choices' => array(
		1  => esc_attr__( 'Large Featured Image', 'curtains' ),
		2 => esc_attr__( 'Small Featured Image', 'curtains' ),
		3 => esc_attr__( 'FullWidth Featured Image', 'curtains' ),
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'single_featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'author_bio_box',
	'label'    => __( 'Enable Author Bio Box below single post', 'curtains' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'off',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'social_sharing_box',
	'label'    => __( 'Enable Social Sharing options Box below single post', 'curtains' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'related_posts',
	'label'    => __( 'Show Related Posts', 'curtains' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'off',
	'tooltip' => __('Show the Related Post for Single Blog Page','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'related_posts_hierarchy',
	'label'    => __( 'Related Posts Must Be Shown As:', 'curtains' ),
	'section'  => 'single_blog',
	'type'     => 'radio',
	'choices' => array(
		1  => esc_attr__( 'Related Posts By Tags', 'curtains' ),
		2 => esc_attr__( 'Related Posts By Categories', 'curtains' ) 
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'related_posts',
			'operator' => '==',
			'value'    => true,
		),
    ),
    'tooltip' => __('Select the Hierarchy','curtains'),

) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'comments',
	'label'    => __( ' Show Comments', 'curtains' ),
	'section'  => 'single_blog',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
	'tooltip' => __('Show the Comments for Single Blog Page','curtains'),
) );
/* FOOTER SECTION 
footer panel */

Curtains_Kirki::add_panel( 'footer_panel', array(     
	'title'       => __( 'Footer', 'curtains' ),
	'description' => __( 'Footer Related Options', 'curtains' ),     
) );  

Curtains_Kirki::add_section( 'footer', array(
	'title'          => __( 'Footer','curtains' ),
	'description'    => __( 'Footer related options', 'curtains'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_widgets',
	'label'    => __( 'Footer Widget Area', 'curtains' ),
	'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','curtains'),admin_url('customize.php') ),
	'section'  => 'footer',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );
/* Choose No.Of Footer area */
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_widgets_count',
	'label'    => __( 'Choose No.of widget area you want in footer', 'curtains' ),
	'section'  => 'footer',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( '1', 'curtains' ),
		2  => esc_attr__( '2', 'curtains' ),
		3  => esc_attr__( '3', 'curtains' ),
		4  => esc_attr__( '4', 'curtains' ),
	),
	'default'  => 4,
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'copyright',
	'label'    => __( 'Footer Copyright Text', 'curtains' ),
	'section'  => 'footer',
	'type'     => 'textarea',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_top_margin',
	'label'    => __( 'Footer Top Margin', 'curtains' ),
	'description' => __('Select the top margin of footer in pixels','curtains'),
	'section'  => 'footer',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.site-footer',
			'property' => 'margin-top',
			'units' => 'px',
		),
	),
	'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Curtains_Kirki::add_section( 'footer_image', array(
	'title'          => __( 'Footer Image','curtains' ),
	'description'    => __( 'Custom Footer Image options', 'curtains'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_image',
	'label'    => __( 'Upload Footer Background Image', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-image',
		),
	),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_size',
	'label'    => __( 'Footer Background Size', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'radio-buttonset',
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'curtains' ),
		'contain' => esc_attr__( 'Contain', 'curtains' ),
		'auto'  => esc_attr__( 'Auto', 'curtains' ),
		'inherit'  => esc_attr__( 'Inherit', 'curtains' ),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Footer Background Image Size','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_repeat',
	'label'    => __( 'Footer Background Repeat', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'curtains'),
        'repeat' => esc_attr__('Repeat', 'curtains'),
        'repeat-x' => esc_attr__('Repeat Horizontally','curtains'),
        'repeat-y' => esc_attr__('Repeat Vertically','curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_position',
	'label'    => __( 'Footer Background Position', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'curtains'),
        'center center' => esc_attr__('Center Center', 'curtains'),
        'center bottom' => esc_attr__('Center Bottom', 'curtains'),
        'left top' => esc_attr__('Left Top', 'curtains'),
        'left center' => esc_attr__('Left Center', 'curtains'),
        'left bottom' => esc_attr__('Left Bottom', 'curtains'),
        'right top' => esc_attr__('Right Top', 'curtains'),
        'right center' => esc_attr__('Right Center', 'curtains'),
        'right bottom' => esc_attr__('Right Bottom', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'center center',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_attachment',
	'label'    => __( 'Footer Background Attachment', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'curtains'),
        'fixed' => esc_attr__('Fixed', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'scroll',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_overlay',
	'label'    => __( 'Enable Footer( Background ) Overlay', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',
) );
  
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_overlay_color',
	'label'    => __( 'Footer Overlay ( Background )color', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#E5493A', 
	'active_callback' => array(
		array(
			'setting'  => 'footer_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output'   => array(
		array(
			'element'  => '.overlay-footer',
			'property' => 'background-color',
		),
	),
) );


// single page section //

Curtains_Kirki::add_section( 'single_page', array(
	'title'          => __( 'Single Page','curtains' ),
	'description'    => __( 'Single Page Related Options', 'curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'single_page_featured_image',
	'label'    => __( 'Enable Single Page Featured Image', 'curtains' ),
	'section'  => 'single_page',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'single_page_featured_image_size',
	'label'    => __( 'Single Page Featured Image Size', 'curtains' ),
	'section'  => 'single_page',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( 'Normal', 'curtains' ),
		2 => esc_attr__( 'FullWidth', 'curtains' ) 
	),
	'default'  => 1,
	'active_callback' => array(
		array(
			'setting'  => 'single_page_featured_image',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

// Layout section //

Curtains_Kirki::add_section( 'layout', array(
	'title'          => __( 'Layout','curtains' ),
	'description'    => __( 'Layout Related Options', 'curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'site-style',
	'label'    => __( 'Site Style', 'curtains' ),
	'section'  => 'layout',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'wide' =>  esc_attr__('Wide', 'curtains'),
        'boxed' =>  esc_attr__('Boxed', 'curtains'),
        'fluid' =>  esc_attr__('Fluid', 'curtains'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'curtains'),
    ),
	'default'  => 'wide',
	'tooltip' => __('Select the default site layout. Defaults to "Wide".','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'sidebar_position',
	'label'    => __( 'Main Layout', 'curtains' ),
	'section'  => 'layout',
	'type'     => 'radio-image',   
	'description' => __('Select main content and sidebar arrancurtainsent.','curtains'),
	'choices' => array(
		'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
	'default'  => 'right',
	'tooltip' => __('This layout will be reflected in all pages unless unique layout template is set for specific page','curtains'),
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'body_top_margin',
	'label'    => __( 'Body Top Margin', 'curtains' ),
	'description' => __('Select the top margin of body element in pixels','curtains'),
	'section'  => 'layout',
	'type'     => 'number',
	'choices' => array(
		'min' => 0,
		'max' => 200,
		'step' => 1,
	),
	'active_callback'    => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'margin-top',
			'units'    => 'px',
		),
	),
	'default'  => 0,
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'body_bottom_margin',
	'label'    => __( 'Body Bottom Margin', 'curtains' ),
	'description' => __('Select the bottom margin of body element in pixels','curtains'),
	'section'  => 'layout',
	'type'     => 'number',
	'choices' => array(
		'min' => 0,
		'max' => 200,
		'step' => 1,
	),
	'active_callback'    => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'margin-bottom',
			'units'    => 'px',
		),
	),
	'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Curtains_Kirki::add_section( 'layout', array(
	'title'          => __( 'Layout','curtains' ),   
	'description'    => __( 'Layout settings that affects overall site', 'curtains'),
	'panel'          => 'curtains_options', // Not typically needed.
) );



Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'primary_sidebar_width',
	'label'    => __( 'Primary Sidebar Width', 'curtains' ),
	'section'  => 'layout',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => __( 'One Column', 'curtains' ),
		'2' => __( 'Two Column', 'curtains' ),
		'3' => __( 'Three Column', 'curtains' ),
		'4' => __( 'Four Column', 'curtains' ),
		'5' => __( 'Five Column ', 'curtains' ),
	),
	'default'  => '5',  
	'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'secondary_sidebar_width',
	'label'    => __( 'Secondary Sidebar Width', 'curtains' ),
	'section'  => 'layout',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => __( 'One Column', 'curtains' ),
		'2' => __( 'Two Column', 'curtains' ),
		'3' => __( 'Three Column', 'curtains' ),
		'4' => __( 'Four Column', 'curtains' ),
		'5' => __( 'Five Column ', 'curtains' ),
	),            
	'default'  => '5',  
	'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','curtains'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Curtains_Kirki::add_panel( 'footer_panel', array(     
	'title'       => __( 'Footer', 'curtains' ),
	'description' => __( 'Footer Related Options', 'curtains' ),     
) );  

Curtains_Kirki::add_section( 'footer', array(
	'title'          => __( 'Footer','curtains' ),
	'description'    => __( 'Footer related options', 'curtains'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_widgets',
	'label'    => __( 'Footer Widget Area', 'curtains' ),
	'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','curtains'),admin_url('customize.php') ),
	'section'  => 'footer',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );
/* Choose No.Of Footer area */
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_widgets_count',
	'label'    => __( 'Choose No.of widget area you want in footer', 'curtains' ),
	'section'  => 'footer',
	'type'     => 'radio-buttonset',
	'choices' => array(
		1  => esc_attr__( '1', 'curtains' ),
		2  => esc_attr__( '2', 'curtains' ),
		3  => esc_attr__( '3', 'curtains' ),
		4  => esc_attr__( '4', 'curtains' ),
	),
	'default'  => 4,
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'copyright',
	'label'    => __( 'Footer Copyright Text', 'curtains' ),
	'section'  => 'footer',
	'type'     => 'textarea',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_top_margin',
	'label'    => __( 'Footer Top Margin', 'curtains' ),
	'description' => __('Select the top margin of footer in pixels','curtains'),
	'section'  => 'footer',
	'type'     => 'number',
	'choices' => array(
		'min' => 1,
		'max' => 1000,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.site-footer',
			'property' => 'margin-top',
			'units' => 'px',
		),
	),
	'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Curtains_Kirki::add_section( 'footer_image', array(
	'title'          => __( 'Footer Image','curtains' ),
	'description'    => __( 'Custom Footer Image options', 'curtains'),
	'panel'          => 'footer_panel', // Not typically needed.
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_image',
	'label'    => __( 'Upload Footer Background Image', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-image',
		),
	),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_size',
	'label'    => __( 'Footer Background Size', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'radio-buttonset',
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'curtains' ),
		'contain' => esc_attr__( 'Contain', 'curtains' ),
		'auto'  => esc_attr__( 'Auto', 'curtains' ),
		'inherit'  => esc_attr__( 'Inherit', 'curtains' ),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'cover',
	'tooltip' => __('Footer Background Image Size','curtains'),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_repeat',
	'label'    => __( 'Footer Background Repeat', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'curtains'),
        'repeat' => esc_attr__('Repeat', 'curtains'),
        'repeat-x' => esc_attr__('Repeat Horizontally','curtains'),
        'repeat-y' => esc_attr__('Repeat Vertically','curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_position',
	'label'    => __( 'Footer Background Position', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'curtains'),
        'center center' => esc_attr__('Center Center', 'curtains'),
        'center bottom' => esc_attr__('Center Bottom', 'curtains'),
        'left top' => esc_attr__('Left Top', 'curtains'),
        'left center' => esc_attr__('Left Center', 'curtains'),
        'left bottom' => esc_attr__('Left Bottom', 'curtains'),
        'right top' => esc_attr__('Right Top', 'curtains'),
        'right center' => esc_attr__('Right Center', 'curtains'),
        'right bottom' => esc_attr__('Right Bottom', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'center center',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_bg_attachment',
	'label'    => __( 'Footer Background Attachment', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'curtains'),
        'fixed' => esc_attr__('Fixed', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.footer-image',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'footer_bg_image',
			'operator' => '=',
			'value'    => true,
		),
	),
	'default'  => 'scroll',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_overlay',
	'label'    => __( 'Enable Footer( Background ) Overlay', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' )
	),
	'default'  => 'off',
) );
  
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'footer_overlay_color',
	'label'    => __( 'Footer Overlay ( Background )color', 'curtains' ),
	'section'  => 'footer_image',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#E5493A', 
	'active_callback' => array(
		array(
			'setting'  => 'footer_overlay',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output'   => array(
		array(
			'element'  => '.overlay-footer',
			'property' => 'background-color',
		),
	),
) );

//  social network panel //

Curtains_Kirki::add_panel( 'social_panel', array(
	'title'        =>__( 'Social Networks', 'curtains'),
	'description'  =>__( 'social networks', 'curtains'),
	'priority'  =>11,	
));

//social sharing box section

Curtains_Kirki::add_section( 'social_sharing_box', array(
	'title'          =>__( 'Social Sharing Box', 'curtains'),
	'description'   =>__('Social Sharing box related options', 'curtains'),
	'panel'			 =>'social_panel',
));

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'facebook_sb',
	'label'    => __( 'Enable facebook sharing option below single post', 'curtains' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'twitter_sb',
	'label'    => __( 'Enable twitter sharing option below single post', 'curtains' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'linkedin_sb',
	'label'    => __( 'Enable linkedin sharing option below single post', 'curtains' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'google-plus_sb',
	'label'    => __( 'Enable googleplus sharing option below single post', 'curtains' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'email_sb',
	'label'    => __( 'Enable email sharing option below single post', 'curtains' ),
	'section'  => 'social_sharing_box',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'on',
) );
//  slider panel //

Curtains_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'curtains' ),  
	'description' => __( 'Flex slider related options', 'curtains' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Curtains_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','curtains' ),
	'description'    => __( 'Flexcaption Related Options', 'curtains'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Curtains_Kirki::add_field( 'curtains', array( 
	'settings' => 'enable_flex_caption_edit',
	'label'    => __( 'Enable Custom Flexcaption Settings', 'curtains' ),
	'section'  => 'flex_caption_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'curtains' ),
		'off' => esc_attr__( 'Disable', 'curtains' ) 
	),
	'default'  => 'off',
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'curtains' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'curtains' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'center',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'curtains' ),
		'right' => esc_attr__( 'Right', 'curtains' ),
		'center' => esc_attr__( 'Center', 'curtains' ),
		'justify' => esc_attr__( 'Justify', 'curtains' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
 Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'curtains' ),
	'tooltip' => __('Select how far from left','curtains'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '20',
	'choices'     => array(
		'min'  => 0,
		'max'  => 64,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'left',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
 Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'curtains' ),
	'tooltip' => __('Select how far from bottom','curtains'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '50',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'bottom',
			'suffix' => 'px',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'curtains' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '60',
	'tooltip' => __('Select Flexcaption Background Width','curtains'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'curtains' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width','curtains'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'curtains' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption p,.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption p a,.flexslider .slides .flex-caption p a,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

 if( class_exists( 'WooCommerce' ) ) {
	Curtains_Kirki::add_section( 'woocommerce_section', array(
		'title'          => __( 'WooCommerce','curtains' ),
		'description'    => __( 'Theme options related to woocommerce', 'curtains'),
		'priority'       => 11, 

		'theme_supports' => '', // Rarely needed.
	) );
	Curtains_Kirki::add_field( 'woocommerce', array(
		'settings' => 'woocommerce_sidebar',
		'label'    => __( 'Enable Woocommerce Sidebar', 'curtains' ),
		'description' => __('Enable Sidebar for shop page','curtains'),
		'section'  => 'woocommerce_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'curtains' ),
			'off' => esc_attr__( 'Disable', 'curtains' ) 
		),

		'default'  => 'on',
	) );
}
	
// background color ( rename )

Curtains_Kirki::add_section( 'colors', array(
	'title'          => __( 'Background Color','curtains' ),
	'description'    => __( 'This will affect overall site background color', 'curtains'),
	//'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 11,
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'general_background_color',
	'label'    => __( 'General Background Color', 'curtains' ),
	'section'  => 'colors',
	'type'     => 'color',
	'alpha' => true,
	'default'  => '#ffffff',
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-color',
		),
	),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'content_background_color',
	'label'    => __( 'Content Background Color', 'curtains' ),
	'section'  => 'colors',
	'type'     => 'color',
	'description' => __('when you are select boxed layout content background color will reflect the grid area','curtains'), 
	'alpha' => true, 
	'default'  => '#ffffff',
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'general_background_image',
	'label'    => __( 'General Background Image', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-image',
		),
	),
) );

// background image ( general & boxed layout ) //


Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'general_background_repeat',
	'label'    => __( 'General Background Repeat', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'curtains'),
        'repeat' => esc_attr__('Repeat', 'curtains'),
        'repeat-x' => esc_attr__('Repeat Horizontally','curtains'),
        'repeat-y' => esc_attr__('Repeat Vertically','curtains'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-repeat',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'general_background_size',
	'label'    => __( 'General Background Size', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'curtains' ),
		'contain' => esc_attr__( 'Contain', 'curtains' ),
		'auto'  => esc_attr__( 'Auto', 'curtains' ),
		'inherit'  => esc_attr__( 'Inherit', 'curtains' ),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-size',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'cover',  
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'general_background_attachment',
	'label'    => __( 'General Background Attachment', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'curtains'),
        'fixed' => esc_attr__('Fixed', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-attachment',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image',
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'fixed',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'general_background_position',
	'label'    => __( 'General Background Position', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'curtains'),
        'center center' => esc_attr__('Center Center', 'curtains'),
        'center bottom' => esc_attr__('Center Bottom', 'curtains'),
        'left top' => esc_attr__('Left Top', 'curtains'),
        'left center' => esc_attr__('Left Center', 'curtains'),
        'left bottom' => esc_attr__('Left Bottom', 'curtains'),
        'right top' => esc_attr__('Right Top', 'curtains'),
        'right center' => esc_attr__('Right Center', 'curtains'),
        'right bottom' => esc_attr__('Right Bottom', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => 'body',
			'property' => 'background-position',
		),
	),
	'active_callback'    => array(
		array(
			'setting'  => 'general_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Curtains_Kirki::add_field( 'curtains', array(  
	'settings' => 'content_background_image',
	'label'    => __( 'Content Background Image', 'curtains' ),
	'description' => __('when you are select boxed layout content background image will reflect the grid area','curtains'),
	'section'  => 'background_image',
	'type'     => 'upload',
	'default'  => '',
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-image',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
	),
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'content_background_repeat',
	'label'    => __( 'Content Background Repeat', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'no-repeat' => esc_attr__('No Repeat', 'curtains'),
        'repeat' => esc_attr__('Repeat', 'curtains'),
        'repeat-x' => esc_attr__('Repeat Horizontally','curtains'),
        'repeat-y' => esc_attr__('Repeat Vertically','curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-repeat',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'repeat',  
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'content_background_size',
	'label'    => __( 'Content Background Size', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
    'choices' => array(
		'cover'  => esc_attr__( 'Cover', 'curtains' ),
		'contain' => esc_attr__( 'Contain', 'curtains' ),
		'auto'  => esc_attr__( 'Auto', 'curtains' ),
		'inherit'  => esc_attr__( 'Inherit', 'curtains' ),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-size',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'cover',  
) );

Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'content_background_attachment',
	'label'    => __( 'Content Background Attachment', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'scroll' => esc_attr__('Scroll', 'curtains'),
        'fixed' => esc_attr__('Fixed', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-attachment',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'fixed',  
) );
Curtains_Kirki::add_field( 'curtains', array(
	'settings' => 'content_background_position',
	'label'    => __( 'Content Background Position', 'curtains' ),
	'section'  => 'background_image',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'center top' => esc_attr__('Center Top', 'curtains'),
        'center center' => esc_attr__('Center Center', 'curtains'),
        'center bottom' => esc_attr__('Center Bottom', 'curtains'),
        'left top' => esc_attr__('Left Top', 'curtains'),
        'left center' => esc_attr__('Left Center', 'curtains'),
        'left bottom' => esc_attr__('Left Bottom', 'curtains'),
        'right top' => esc_attr__('Right Top', 'curtains'),
        'right center' => esc_attr__('Right Center', 'curtains'),
        'right bottom' => esc_attr__('Right Bottom', 'curtains'),
	),
	'output'   => array(
		array(
			'element'  => '.boxed-container',
			'property' => 'background-position',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'site-style',
			'operator' => '==',
			'value'    => 'boxed',
		),
		array(
			'setting'  => 'content_background_image', 
			'operator' => '==',
			'value'    => true,
		),
	),
	'default'  => 'center top',  
) );

do_action('wbls-curtains_pro_customizer_options');
do_action('curtains_child_customizer_options');
