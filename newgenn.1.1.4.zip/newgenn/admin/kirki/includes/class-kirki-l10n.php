<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'newgenn';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'newgenn' ),
				'background-image'      => esc_attr__( 'Background Image', 'newgenn' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'newgenn' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'newgenn' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'newgenn' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'newgenn' ),
				'inherit'               => esc_attr__( 'Inherit', 'newgenn' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'newgenn' ),
				'cover'                 => esc_attr__( 'Cover', 'newgenn' ),
				'contain'               => esc_attr__( 'Contain', 'newgenn' ),
				'background-size'       => esc_attr__( 'Background Size', 'newgenn' ),
				'fixed'                 => esc_attr__( 'Fixed', 'newgenn' ),
				'scroll'                => esc_attr__( 'Scroll', 'newgenn' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'newgenn' ),
				'left-top'              => esc_attr__( 'Left Top', 'newgenn' ),
				'left-center'           => esc_attr__( 'Left Center', 'newgenn' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'newgenn' ),
				'right-top'             => esc_attr__( 'Right Top', 'newgenn' ),
				'right-center'          => esc_attr__( 'Right Center', 'newgenn' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'newgenn' ),
				'center-top'            => esc_attr__( 'Center Top', 'newgenn' ),
				'center-center'         => esc_attr__( 'Center Center', 'newgenn' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'newgenn' ),
				'background-position'   => esc_attr__( 'Background Position', 'newgenn' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'newgenn' ),
				'on'                    => esc_attr__( 'ON', 'newgenn' ),
				'off'                   => esc_attr__( 'OFF', 'newgenn' ),
				'all'                   => esc_attr__( 'All', 'newgenn' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'newgenn' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'newgenn' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'newgenn' ),
				'greek'                 => esc_attr__( 'Greek', 'newgenn' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'newgenn' ),
				'khmer'                 => esc_attr__( 'Khmer', 'newgenn' ),
				'latin'                 => esc_attr__( 'Latin', 'newgenn' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'newgenn' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'newgenn' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'newgenn' ),
				'arabic'                => esc_attr__( 'Arabic', 'newgenn' ),
				'bengali'               => esc_attr__( 'Bengali', 'newgenn' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'newgenn' ),
				'tamil'                 => esc_attr__( 'Tamil', 'newgenn' ),
				'telugu'                => esc_attr__( 'Telugu', 'newgenn' ),
				'thai'                  => esc_attr__( 'Thai', 'newgenn' ),
				'serif'                 => _x( 'Serif', 'font style', 'newgenn' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'newgenn' ),
				'monospace'             => _x( 'Monospace', 'font style', 'newgenn' ),
				'font-family'           => esc_attr__( 'Font Family', 'newgenn' ),
				'font-size'             => esc_attr__( 'Font Size', 'newgenn' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'newgenn' ),
				'line-height'           => esc_attr__( 'Line Height', 'newgenn' ),
				'font-style'            => esc_attr__( 'Font Style', 'newgenn' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'newgenn' ),
				'top'                   => esc_attr__( 'Top', 'newgenn' ),
				'bottom'                => esc_attr__( 'Bottom', 'newgenn' ),
				'left'                  => esc_attr__( 'Left', 'newgenn' ),
				'right'                 => esc_attr__( 'Right', 'newgenn' ),
				'center'                => esc_attr__( 'Center', 'newgenn' ),
				'justify'               => esc_attr__( 'Justify', 'newgenn' ),
				'color'                 => esc_attr__( 'Color', 'newgenn' ),
				'add-image'             => esc_attr__( 'Add Image', 'newgenn' ),
				'change-image'          => esc_attr__( 'Change Image', 'newgenn' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'newgenn' ),
				'add-file'              => esc_attr__( 'Add File', 'newgenn' ),
				'change-file'           => esc_attr__( 'Change File', 'newgenn' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'newgenn' ),
				'remove'                => esc_attr__( 'Remove', 'newgenn' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'newgenn' ),
				'variant'               => esc_attr__( 'Variant', 'newgenn' ),
				'subsets'               => esc_attr__( 'Subset', 'newgenn' ),
				'size'                  => esc_attr__( 'Size', 'newgenn' ),
				'height'                => esc_attr__( 'Height', 'newgenn' ),
				'spacing'               => esc_attr__( 'Spacing', 'newgenn' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'newgenn' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'newgenn' ),
				'light'                 => esc_attr__( 'Light 200', 'newgenn' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'newgenn' ),
				'book'                  => esc_attr__( 'Book 300', 'newgenn' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'newgenn' ),
				'regular'               => esc_attr__( 'Normal 400', 'newgenn' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'newgenn' ),
				'medium'                => esc_attr__( 'Medium 500', 'newgenn' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'newgenn' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'newgenn' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'newgenn' ),
				'bold'                  => esc_attr__( 'Bold 700', 'newgenn' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'newgenn' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'newgenn' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'newgenn' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'newgenn' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'newgenn' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'newgenn' ),
				'add-new'           	=> esc_attr__( 'Add new', 'newgenn' ),
				'row'           		=> esc_attr__( 'row', 'newgenn' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'newgenn' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'newgenn' ),
				'back'                  => esc_attr__( 'Back', 'newgenn' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'newgenn' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'newgenn' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'newgenn' ),
				'none'                  => esc_attr__( 'None', 'newgenn' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'newgenn' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'newgenn' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'newgenn' ),
				'initial'               => esc_attr__( 'Initial', 'newgenn' ),
				'select-page'           => esc_attr__( 'Select a Page', 'newgenn' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'newgenn' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'newgenn' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'newgenn' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'newgenn' ),
			);

			$config = apply_filters( 'kirki/config', array() );

			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
