<?php
/**
 * @package NewGenn
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php do_action('newgenn_before_entry_header'); ?>

		<header class="entry-header">
			<?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>

				<?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
					<footer class="entry-meta">
						<?php if(function_exists('newgenn_entry_top_meta') ) {
						    newgenn_entry_top_meta(); 
						} ?> 
					</footer><!-- .entry-footer -->
				<?php endif;?>  
		</header><!-- .entry-header --> 

	<?php do_action('newgenn_after_entry_header'); ?>

<div class="entry-content">
	<?php 
		$featured_image = get_theme_mod( 'featured_image',true );   	   	  
			if( $featured_image ) : ?> 
				<div class="post-thumb blog-thumb">
					<?php
					if( function_exists( 'newgenn_featured_image' ) ) :
						newgenn_featured_image();
					endif;
					?>
			    </div>
			<?php endif; ?>    

	<div class="entry-body">   
		<?php
			/* translators: %s: Name of current post */
			the_content(); 
		?>
	</div>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'newgenn' ),
				'after'  => '</div>',
			) );
		?>
	<br class="clear" />
</div>
	<?php do_action('newgenn_before_entry_footer'); ?>
	
	<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
		<footer class="entry-footer">
			<?php if(function_exists('newgenn_entry_bottom_meta') ) {
			     newgenn_entry_bottom_meta();
			} ?>
		</footer><!-- .entry-footer -->
	<?php endif;?>
<?php do_action('newgenn_after_entry_footer'); ?>

</article><!-- #post-## -->