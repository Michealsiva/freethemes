<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package NewGenn
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site <?php echo newgenn_site_style_class(); ?>">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'newgenn' ); ?></a>
	<?php do_action('newgenn_before_header'); ?>
	<header id="masthead" class="site-header header-image header-wrap <?php echo newgenn_site_style_header_class(); ?>" role="banner">
		<?php if ( get_theme_mod ('header_overlay',false ) ) { 
				   echo '<div class="overlay overlay-header"></div>';     
				} ?>  
				
    <?php if( is_active_sidebar( 'header-top-left' )  || is_active_sidebar( 'header-top-right' ) ): ?>
	   <div class="top-nav">
			<div class="container">		
				<div class="eight columns">
					<div class="cart-left">
						<?php dynamic_sidebar('header-top-left' ); ?>
					</div>
				</div>

				<div class="eight columns">
					<div class="cart-right">
						<?php dynamic_sidebar('header-top-right' ); ?>  
					</div>
				</div>

			</div>
		</div> <!-- .top-nav -->
	<?php endif; ?>

		<div class="container">
			<div class="branding eight columns">     
				<div class="site-branding logo">
				<?php  
						   // $header_text = get_theme_mod( 'header_text' );
							$logo_title = get_theme_mod( 'logo_title' );
							$logo = get_theme_mod( 'logo', '' );  
							$tagline = get_theme_mod( 'tagline',true);
							if( $logo_title && function_exists( 'the_custom_logo' ) ) {
                                the_custom_logo();     
					        }elseif( $logo != '' && $logo_title ) { ?>
							   <h1 class="site-title img-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($logo) ?>"></a></h1>
					<?php	}else { ?>
								<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
						    <?php } ?>
						<?php if( $tagline ) : ?>
								<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
						<?php endif; 
					?>
				</div>
			</div>

			<div class="eight columns"> 
				<div class="top-right">
					<?php dynamic_sidebar( 'top-right' ); ?>      
				</div>					
			</div>
		</div>
	

	</header><!-- #masthead -->

		<div class="nav-wrap">
			<div class="container"> 
					<nav id="site-navigation" class="main-navigation sixteen columns" role="navigation">
						<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><?php echo apply_filters('newgenn_responsive_menu_title', __('Primary Menu','newgenn') ); ?></button>
						<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
					</nav><!-- #site-navigation -->
					<?php do_action('newgenn_after_primary_nav'); ?>
			</div>
		</div>

		<?php do_action('newgenn_after_header'); ?>

<?php if ( function_exists( 'is_woocommerce' ) || function_exists( 'is_cart' ) || function_exists( 'is_chechout' ) ) :
	 if ( is_woocommerce() || is_cart() || is_checkout() ) { ?>
	   <?php $breadcrumb = get_theme_mod( 'breadcrumb',true ); ?>    
		   <div class="breadcrumb">
				<div class="container">
					<div class="breadcrumb-left eight columns">
						<h4><?php woocommerce_page_title(); ?></h4>   			
					</div>
					<?php if( $breadcrumb ) : ?>
						<div class="breadcrumb-right eight columns">
							<?php woocommerce_breadcrumb(); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
	<?php } 
	endif; ?>

