<?php
/**
 * The template used for displaying page breadcrumb
 *
 * @package newgenn
 */
 
 

   

$breadcrumb = get_theme_mod( 'breadcrumb',true ); ?>  
	<div class="breadcrumb-wrap">
		<div class="container">
			<div class="sixteen columns breadcrumb">	
				<header class="entry-header">
					<h1 class="entry-title"><?php the_title(); ?></h1>
				</header><!-- .entry-header -->
				<?php $breadcrumb = get_theme_mod( 'breadcrumb',true ); 
					if( $breadcrumb ) : ?>
					<div id="breadcrumb" role="navigation">
						<?php newgenn_breadcrumbs(); ?>
					</div>
				<?php endif; ?>
			</div>
		</div> 
	</div>