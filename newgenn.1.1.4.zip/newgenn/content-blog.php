<?php
/**
 * Template part for displaying posts.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package newgenn
 */
?>
<?php do_action('newgenn_blog_layout_class_wrapper_before'); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	

	<?php do_action('newgenn_before_entry_header'); ?>

		<header class="entry-header">
	<div class="entry-meta header-entry-meta">
		<a href="<?php the_permalink() ?>">
			<i class="fa fa-calendar"></i>
			<?php webulous_post_date(); ?> 
		</a>
	</div><!-- .entry-meta -->								
	<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
	<?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
		<div class="entry-title-meta entry-meta">
			 <?php newgenn_entry_top_meta(); ?>	    
		</div>
    <?php endif; ?>
</header>  

	<?php do_action('newgenn_after_entry_header'); ?>
	<?php 
		$featured_image = get_theme_mod( 'featured_image',true );
	  
	if( $featured_image ) : ?> 
		<div class="post-thumb blog-thumb">
			<?php
			if( function_exists( 'newgenn_featured_image' ) ) :
				newgenn_featured_image();
			endif;
			?>
	    </div>
	<?php endif; ?> 
	<div class="entry-content">
		<?php
			/* translators: %s: Name of current post */
			the_content();
		?>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'newgenn' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

<?php do_action('newgenn_before_entry_footer'); ?>
	<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
		<footer class="entry-footer">
			<?php if(function_exists('newgenn_entry_bottom_meta') ) {
			     newgenn_entry_bottom_meta();
			} ?>
		</footer><!-- .entry-footer -->
	<?php endif;?>
<?php do_action('newgenn_after_entry_footer'); ?>

</article><!-- #post-## -->

<?php do_action('newgenn_blog_layout_class_wrapper_after'); ?>