<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'stronghold';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'stronghold' ),
				'background-image'      => esc_attr__( 'Background Image', 'stronghold' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'stronghold' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'stronghold' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'stronghold' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'stronghold' ),
				'inherit'               => esc_attr__( 'Inherit', 'stronghold' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'stronghold' ),
				'cover'                 => esc_attr__( 'Cover', 'stronghold' ),
				'contain'               => esc_attr__( 'Contain', 'stronghold' ),
				'background-size'       => esc_attr__( 'Background Size', 'stronghold' ),
				'fixed'                 => esc_attr__( 'Fixed', 'stronghold' ),
				'scroll'                => esc_attr__( 'Scroll', 'stronghold' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'stronghold' ),
				'left-top'              => esc_attr__( 'Left Top', 'stronghold' ),
				'left-center'           => esc_attr__( 'Left Center', 'stronghold' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'stronghold' ),
				'right-top'             => esc_attr__( 'Right Top', 'stronghold' ),
				'right-center'          => esc_attr__( 'Right Center', 'stronghold' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'stronghold' ),
				'center-top'            => esc_attr__( 'Center Top', 'stronghold' ),
				'center-center'         => esc_attr__( 'Center Center', 'stronghold' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'stronghold' ),
				'background-position'   => esc_attr__( 'Background Position', 'stronghold' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'stronghold' ),
				'on'                    => esc_attr__( 'ON', 'stronghold' ),
				'off'                   => esc_attr__( 'OFF', 'stronghold' ),
				'all'                   => esc_attr__( 'All', 'stronghold' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'stronghold' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'stronghold' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'stronghold' ),
				'greek'                 => esc_attr__( 'Greek', 'stronghold' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'stronghold' ),
				'khmer'                 => esc_attr__( 'Khmer', 'stronghold' ),
				'latin'                 => esc_attr__( 'Latin', 'stronghold' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'stronghold' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'stronghold' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'stronghold' ),
				'arabic'                => esc_attr__( 'Arabic', 'stronghold' ),
				'bengali'               => esc_attr__( 'Bengali', 'stronghold' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'stronghold' ),
				'tamil'                 => esc_attr__( 'Tamil', 'stronghold' ),
				'telugu'                => esc_attr__( 'Telugu', 'stronghold' ),
				'thai'                  => esc_attr__( 'Thai', 'stronghold' ),
				'serif'                 => _x( 'Serif', 'font style', 'stronghold' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'stronghold' ),
				'monospace'             => _x( 'Monospace', 'font style', 'stronghold' ),
				'font-family'           => esc_attr__( 'Font Family', 'stronghold' ),
				'font-size'             => esc_attr__( 'Font Size', 'stronghold' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'stronghold' ),
				'line-height'           => esc_attr__( 'Line Height', 'stronghold' ),
				'font-style'            => esc_attr__( 'Font Style', 'stronghold' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'stronghold' ),
				'top'                   => esc_attr__( 'Top', 'stronghold' ),
				'bottom'                => esc_attr__( 'Bottom', 'stronghold' ),
				'left'                  => esc_attr__( 'Left', 'stronghold' ),
				'right'                 => esc_attr__( 'Right', 'stronghold' ),
				'center'                => esc_attr__( 'Center', 'stronghold' ),
				'justify'               => esc_attr__( 'Justify', 'stronghold' ),
				'color'                 => esc_attr__( 'Color', 'stronghold' ),
				'add-image'             => esc_attr__( 'Add Image', 'stronghold' ),
				'change-image'          => esc_attr__( 'Change Image', 'stronghold' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'stronghold' ),
				'add-file'              => esc_attr__( 'Add File', 'stronghold' ),
				'change-file'           => esc_attr__( 'Change File', 'stronghold' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'stronghold' ),
				'remove'                => esc_attr__( 'Remove', 'stronghold' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'stronghold' ),
				'variant'               => esc_attr__( 'Variant', 'stronghold' ),
				'subsets'               => esc_attr__( 'Subset', 'stronghold' ),
				'size'                  => esc_attr__( 'Size', 'stronghold' ),
				'height'                => esc_attr__( 'Height', 'stronghold' ),
				'spacing'               => esc_attr__( 'Spacing', 'stronghold' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'stronghold' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'stronghold' ),
				'light'                 => esc_attr__( 'Light 200', 'stronghold' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'stronghold' ),
				'book'                  => esc_attr__( 'Book 300', 'stronghold' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'stronghold' ),
				'regular'               => esc_attr__( 'Normal 400', 'stronghold' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'stronghold' ),
				'medium'                => esc_attr__( 'Medium 500', 'stronghold' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'stronghold' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'stronghold' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'stronghold' ),
				'bold'                  => esc_attr__( 'Bold 700', 'stronghold' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'stronghold' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'stronghold' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'stronghold' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'stronghold' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'stronghold' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'stronghold' ),
				'add-new'           	=> esc_attr__( 'Add new', 'stronghold' ),
				'row'           		=> esc_attr__( 'row', 'stronghold' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'stronghold' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'stronghold' ),
				'back'                  => esc_attr__( 'Back', 'stronghold' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'stronghold' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'stronghold' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'stronghold' ),
				'none'                  => esc_attr__( 'None', 'stronghold' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'stronghold' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'stronghold' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'stronghold' ),
				'initial'               => esc_attr__( 'Initial', 'stronghold' ),
				'select-page'           => esc_attr__( 'Select a Page', 'stronghold' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'stronghold' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'stronghold' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'stronghold' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'stronghold' ),
			);

			$config = apply_filters( 'kirki/config', array() );

			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
