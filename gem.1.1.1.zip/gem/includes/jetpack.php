<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package gem
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function gem_jetpack_setup() {
	add_theme_support( 'infinite-scroll', array(
		'container' => 'main',
		'footer'    => 'page',
	) );
}
add_action( 'after_setup_theme', 'gem_jetpack_setup' );
