( function( $ ) {
	$(function() {
		/*
		 * This code is based on Theme Foundry's "Make" theme
		 * Make WordPress Theme, Copyright 2014 The Theme Foundry
		 * Make is distributed under the terms of the GNU GPL
		 */
		$('#customize-theme-controls').append('<div class="customizer-review-link"><p>Star this theme on <a href="https://wordpress.org/support/view/theme-reviews/uniq" target="_blank">WordPress.org! <br/> Leave us a <span class="dashicons dashicons-star-filled"></span><span class="dashicons dashicons-star-filled"></span><span class="dashicons dashicons-star-filled"></span><span class="dashicons dashicons-star-filled"></span><span class="dashicons dashicons-star-filled"></span></a> rating </p></div>');
    });
} )( jQuery );