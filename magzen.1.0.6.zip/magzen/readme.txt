=== MagZen ===
Contributors: Webulous
Tags:  featured-images, right-sidebar, sticky-post, translation-ready, custom-background,  custom-menu,  threaded-comments , blog, news
Requires at least: 4.0
Tested up to: 4.8.2
Stable tag: 1.0.6
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

MagZen is best suited for all types of site and uses Theme Customizer.

MagZen WordPress Theme, Copyright 2017 Webulousthemes

== Description ==
MagZen is a perfect responsive magazine style WordPress theme. Suitable for news, newspaper, magazine, publishing, business and any kind of sites. core feature of WordPress  Has 3 Footer Widget Areas.

== Frequently Asked Questions == 
== Installation ==
  
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the magzen.zip file. Click Install Now.
3. Click Activate to use your new theme right away. 

= Theme Features Usage =
All available options can be used from Appearance->Customize

== Changelog ==
= 1.0.6 = 
 * Updated font-awesome icons 
 * Fix header image issue and add header video option

= 1.0.5 =
* minor error fix

= 1.0.4 =
* Screenshot change

= 1.0.3 =
* Fix js error

= 1.0.2 =
* Modify the admin page styles

= 1.0.1 =
* Fix some issue

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.6 = 
 * Updated font-awesome icons 
 * Fix header image issue and add header video option
 
== Resources ==
* {_s}, GPLv3, http://underscores.me/
* {Skeleton}, MIT, https://github.com/dhg/Skeleton#license
* {NewsTicker} © Risq, GNU General Public License v2.0 ,https://github.com/risq/jquery-advanced-news-ticker/blob/master/LICENSE.txt
* {FontAwesome} © Dave Gandy, SIL OFL 1.1 and MIT ,https://fortawesome.github.io/Font-Awesome
* Screenshot Images is licensed under CC0 Public Domain License.
   * image © 2015 Pixabay, CC0 1.0 ,https://pixabay.com/en/girl-music-pink-fashion-listen-1990347/
   * image © 2015 Pixabay, CC0 1.0 ,https://pixabay.com/en/above-adventure-aerial-air-amazing-736879/
   * image © 2015 Pixabay, CC0 1.0 ,https://pixabay.com/en/spa-meditation-model-red-dress-2001305/
   * image © 2015 Flickr, CC0 1.0 , https://www.flickr.com/photos/justwp/31705036864/
* All Images inside the images folder are created by own. Those Image are licensed under CC0 Public Domain License GPLv2.


