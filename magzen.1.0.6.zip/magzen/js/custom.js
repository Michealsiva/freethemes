(function($){
	$('.newsticker').newsTicker({
      row_height: 35,
      max_rows: 1,
      speed: 500,
      direction: 'down',
      duration: 1000,
      autostart: 1,
      pauseOnHover: 1
   }); 


})(jQuery);